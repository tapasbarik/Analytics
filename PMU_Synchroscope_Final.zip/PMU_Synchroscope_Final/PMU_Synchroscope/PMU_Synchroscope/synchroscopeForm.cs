﻿// ************************************************************************************************************
//************************************openECA Project-PMU_Synchroscope Analytic********************************
//Code for a remote synchrophasor based synchroscope analytic as a part of the openECA project sponsored by DOE
//Project Partners:Dominion Virginia Power
//                 Virginia Tech
//                 Grid Protection Alliance
//Developer-Tapas Kumar Barik
//File:Synchroscope_Form.cs Windows Form Application
//Inputs:Voltage phasors(both magnitude and angle),frequency,and ROC of frequency from two remote buses to be 
//       synchronized on two separate islands.
//Output:Boolean variable-breaker which is true if the command to the synchronizing breaker is initiated after
//       all the requirements are satisfied.
//*************************************************************************************************************

using System;
using ECAClientFramework;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;


namespace PMU_Synchroscope
{
    public partial class Synchroscope_Form : Form
    {
        #region[Class fields]
        //Tolerance Limits
        private double phaseangle_tolerance;          //Phase Angle tolerance in degrees i.e +15/-15 degrees
        private double frequency_tolerance;          //Frequency_tolerance(maximum slip allowed) in Hz.
        private double Vmag_tolerance;              //Voltage Magnitude tolerance in pu i.e. 0.95 pu to 1.05 p.Angular_position.
        private double total_delay=1 ;             //(in ms)initialized earlier.Later can be manually entered in GUI

        //System data
        private double Incoming_phasor_angle, Ref_phasor_angle, dfdt_ref, dfdt_incoming;
        private double Ref_Phasor_Frequency = 60.01;          //Initialize
        private double Incoming_Phasor_Frequency = 60.00;
        private double Ref_Phasor_Voltage = 150;
        private double phasorMag = 150;                    //Initial V_mag size as per limitations of GUI
        private double Incoming_Phasor_Voltage = 150;
        private int WIDTH = 300, HEIGHT = 300;          //size and dimensions of bitmap

        private double Advanced_Angle;           //Advanced_Angle is a function of slip frequency and total_delay introduced 
        private double Angular_position, allowed_inititation_angle, allowed_termination_angle; //in degrees
        private double refresh_time = (1000 / SystemSettings.FramesPerSecond);      //refresh time between two frames
        private int centre_x, centre_y;     // coordinates of center of the circle
        private int x, y;                  //phasorMag coordinate
        private int rev;                  //for advanced angle calculation
        private int xnew, ynew, x_start, y_start, x_end, y_end;   //for adjusted total_delay phase angle tolerance window
        private bool breaker_status = false;   //breaker boolean variable is a condition which is true if only the breaker close command 
                                               //is accepted by the algorithm and passed on to control units
        private bool breaker_close_command = false;
        private bool breaker_open_command = false;
        private bool auto = false;                //boolean variable to depict if Auto mode is on or not
        private bool incomingDataStarted = false;//variable to check whether data from openECA has started streaming in

        System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
        Graphics g;
        Bitmap bmp;
        #endregion

        #region[Constructor]
        public Synchroscope_Form()
        {
            InitializeComponent();
        }
        #endregion

        private void Retrieve_total_delay_value_Click(object sender, EventArgs e)
        {
            total_delay = Convert.ToDouble(total_delay_textbox.Text)+ Math.Abs(Algorithm.timespan_inputdelay);
        }

        private void autoModeButton_Click(object sender, EventArgs e)
        {
            auto = true;
            manualModeButton.BackColor = default(Color);
            autoModeButton.BackColor = Color.Red;
        }

        private void manualModeButton_Click(object sender, EventArgs e)
        {
            auto = false;
            autoModeButton.BackColor = default(Color);
            manualModeButton.BackColor = Color.Red;
        }

        //Breaker close Logic
        private void breakerCloseButton_Click(object sender, EventArgs e)      //close Breaker
        {
            if (breaker_close_command == false && breaker_status == false)  //introduced so that breaker command should be given once till CB is closed and not continuous
            {
                if( Math.Abs(Incoming_Phasor_Frequency - Ref_Phasor_Frequency) <= frequency_tolerance && Math.Abs(dfdt_incoming - dfdt_ref) < 0.005 && (Math.Abs((Incoming_Phasor_Voltage - Ref_Phasor_Voltage) / Ref_Phasor_Voltage) <= Vmag_tolerance))//check for frequency and voltage magnitude tolerance and difference of df/dt of both should be near about 0
                {
                    //Forward Case
                    if (Incoming_Phasor_Frequency - Ref_Phasor_Frequency >= 0)
                    {
                        if ((allowed_inititation_angle >= 180 && allowed_termination_angle >= 180)|| (allowed_inititation_angle <= 180 && allowed_termination_angle <= 180))
                        {
                            if (Angular_position >= allowed_inititation_angle && Angular_position <= allowed_termination_angle)
                            {
                                breaker_close_command = true;             // condition to check breaker command is given and true
                            }
                        }
                        else if ((allowed_inititation_angle >= 180 && allowed_termination_angle <= 180)|| (allowed_inititation_angle <= 180 && allowed_termination_angle >= 180))
                        {
                            if ((Angular_position >= allowed_inititation_angle && Angular_position <= 360) || (Angular_position >= 0 && Angular_position <= allowed_termination_angle))
                            {
                                breaker_close_command = true;             // condition to check breaker command is given and true
                            }
                        }
                    }
                    //Reverse Synch Case
                    else if (Incoming_Phasor_Frequency - Ref_Phasor_Frequency < 0) 
                    {
                        if ((allowed_inititation_angle <= 180 && allowed_termination_angle <= 180)|| (allowed_inititation_angle >= 180 && allowed_termination_angle >= 180))
                        {
                            if ((Angular_position) <= allowed_inititation_angle && (Angular_position) >= allowed_termination_angle)
                            {
                                breaker_close_command = true;             // condition to check breaker command is given and true
                            }
                        }
                        else if ((allowed_inititation_angle <= 180 && allowed_termination_angle >= 180)|| (allowed_inititation_angle >= 180 && allowed_termination_angle <= 180))
                        {
                            if (((Angular_position) <= allowed_inititation_angle && (Angular_position) >= 0) || ((Angular_position) <= 360 && (Angular_position) >= allowed_termination_angle))
                            {
                                breaker_close_command = true;             // condition to check breaker command is given and true
                            }
                        }
                    }
                    if (breaker_close_command == true)
                    {
                        System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                        player.SoundLocation = @"C:\WINDOWS\Media\Windows Ding.wav";
                        player.Play();
                    }
                }                       
            }
        }

        //Open breaker provision (can be removed if required) 
        private void breakerOpenButton_Click(object sender, EventArgs e)      //open Breaker Button
        {
            if (breaker_open_command == false && auto == false && breaker_status == true)     //so that in auto/manual mode after breaker command is initiated operator can not give open command manually
            {
                breaker_open_command = true;
                System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                player.SoundLocation = @"C:\WINDOWS\Media\Windows Ding.wav";
                player.Play();
            }
        }

        #region[Plotting Graphs]

        #region[Voltagechart]
        private Thread VoltageThread;
        private double[] VoltageArray1 = new double[60];
        private double[] VoltageArray2 = new double[60];
        private void streamVoltagedata()
        {

            while (incomingDataStarted)
            {
                VoltageArray1[VoltageArray1.Length - 1] = Incoming_Phasor_Voltage / 1000;
                VoltageArray2[VoltageArray2.Length - 1] = Ref_Phasor_Voltage / 1000;
                Array.Copy(VoltageArray1, 1, VoltageArray1, 0, VoltageArray1.Length - 1);
                Array.Copy(VoltageArray2, 1, VoltageArray2, 0, VoltageArray2.Length - 1);
                if (Voltage_Chart.IsHandleCreated)
                {
                    this.Invoke((MethodInvoker)delegate { UpdateVoltagegraph(); });
                }
                else
                {
                    //......
                }

                Thread.Sleep(250);
            }
        }

        private void UpdateVoltagegraph()
        {
            Voltage_Chart.ChartAreas[0].AxisY.Minimum = Math.Ceiling((Ref_Phasor_Voltage / 1000) * 0.95);
            Voltage_Chart.ChartAreas[0].AxisY.Maximum = Math.Ceiling((Ref_Phasor_Voltage / 1000) * 1.05);
            Voltage_Chart.Series["Incoming_Voltage_Mag"].Points.Clear();
            Voltage_Chart.Series["Ref_Voltage_Mag"].Points.Clear();
            for (int i = 0; i < VoltageArray1.Length - 1; ++i)
            {
                Voltage_Chart.Series["Incoming_Voltage_Mag"].Points.AddY(VoltageArray1[i]);
                Voltage_Chart.Series["Ref_Voltage_Mag"].Points.AddY(VoltageArray2[i]);
            }
        }
        #endregion

        #region[Frequencychart]
        private Thread FrequencyThread;
        private double[] FrequencyArray1 = new double[60];
        private double[] FrequencyArray2 = new double[60];
        private void streamFrequencydata()
        {
            while (incomingDataStarted)
            {
                FrequencyArray1[FrequencyArray1.Length - 1] = Algorithm.inputData.test_Incoming_freq;
                FrequencyArray2[FrequencyArray2.Length - 1] = Ref_Phasor_Frequency;
                Array.Copy(FrequencyArray1, 1, FrequencyArray1, 0, FrequencyArray1.Length - 1);
                Array.Copy(FrequencyArray2, 1, FrequencyArray2, 0, FrequencyArray2.Length - 1);
                if (Frequency_chart.IsHandleCreated)
                {
                    this.Invoke((MethodInvoker)delegate { UpdateFrequencygraph(); });
                }
                else
                {
                    //......
                }

                Thread.Sleep(250);
            }
        }

        private void UpdateFrequencygraph()
        {
            Frequency_chart.ChartAreas[0].AxisY.Minimum = Math.Ceiling((Ref_Phasor_Frequency - 0.3) * 100) / 100;
            Frequency_chart.ChartAreas[0].AxisY.Maximum = Math.Ceiling((Ref_Phasor_Frequency + 0.3) * 100) / 100;
            Frequency_chart.Series["Incoming_Frequency"].Points.Clear();
            Frequency_chart.Series["Reference_Frequency"].Points.Clear();
            for (int i = 0; i < FrequencyArray1.Length - 1; ++i)
            {
                Frequency_chart.Series["Incoming_Frequency"].Points.AddY(FrequencyArray1[i]);
                Frequency_chart.Series["Reference_Frequency"].Points.AddY(FrequencyArray2[i]);
            }
        }
        #endregion

        private void startgraphs()
        {
            VoltageThread = new Thread(new ThreadStart(this.streamVoltagedata));
            VoltageThread.IsBackground = true;
            VoltageThread.Start();
            FrequencyThread = new Thread(new ThreadStart(this.streamFrequencydata));
            FrequencyThread.IsBackground = true;
            FrequencyThread.Start();

        }
        #endregion

        private void synchroscopeForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (incomingDataStarted)
            {
                //forecefully stop all started threads
                VoltageThread.Abort();
                FrequencyThread.Abort();
            }
        }

        //Initially load the form
        private void synchroscopeForm_Load(object sender, EventArgs e)
        {
            //create Bitmap
            bmp = new Bitmap(WIDTH + 70, HEIGHT + 70);

            //background color
            this.BackColor = Color.PapayaWhip;

            //center
            centre_x = WIDTH / 2 + 35;
            centre_y = HEIGHT / 2 + 35;

            //Initialize the Initial position of HAND
            Angular_position = 0;

            //Retrieve the tolerance limits from the data entered
            phaseangle_tolerance = Input_screen.Vang_limit;
            Vmag_tolerance = Input_screen.Vmag_limit;
            frequency_tolerance = Input_screen.freq_limit;

            //Timer
            t.Interval =10000;        
            manualModeButton.BackColor = Color.Red;  //initially manual mode
            t.Tick += new EventHandler(this.t_Tick);
            t.Start();
        }

        //timer event handler
        private void t_Tick(object sender, EventArgs e)
        {
            UpdateSynchroscopeForm();
        }

        //Update the form depending upon the stream of data received 
        private void UpdateSynchroscopeForm()
        {
            g = Graphics.FromImage(bmp);

            #region[ calculate x, y coordinate of HAND]

            phasorMag = 150 - ((Ref_Phasor_Voltage - Incoming_Phasor_Voltage) / Ref_Phasor_Voltage) * 150*4; 
            x = centre_x + (int)(phasorMag * Math.Sin(Math.PI * Angular_position / 180));
            y = centre_y - (int)(phasorMag * Math.Cos(Math.PI * Angular_position / 180));

            #endregion

            #region[Basic Graphics and Design]
            Pen p = new Pen(Color.Black, 3);

            //Bitmap color fill
            g.FillRectangle(new SolidBrush(Color.PapayaWhip), 0, 0, WIDTH + 100, HEIGHT + 100);
            //Synchroscope color fill and outline
            g.FillEllipse(new SolidBrush(Color.Khaki), centre_x - WIDTH / 2, centre_y - HEIGHT / 2, WIDTH, HEIGHT);
            g.DrawEllipse(p, centre_x - WIDTH / 2, centre_y - HEIGHT / 2, WIDTH, HEIGHT);
            //Original Angle tolerance window
            g.FillPie(new SolidBrush(Color.PaleGreen), centre_x - 100, centre_y - WIDTH / 2, WIDTH - 100, HEIGHT, (Convert.ToInt32(270 - phaseangle_tolerance)), Convert.ToInt32(2 * phaseangle_tolerance));
            g.DrawPie(p, centre_x - 100, centre_y - WIDTH / 2, WIDTH - 100, HEIGHT, (Convert.ToInt32(270 - phaseangle_tolerance)), Convert.ToInt32(2 * phaseangle_tolerance));    //Angle tolerance window fill and outline

            //Draw reference phasor at 12 o'clock position
            g.DrawLine(p, new Point(centre_x, centre_y - WIDTH / 2), new Point(centre_x, centre_y));

            //draw rotating phasorMag
            Pen p2 = new Pen(Color.SaddleBrown, 7);
            p2.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(p2, new Point(centre_x, centre_y), new Point(x, y));
            #endregion

            #region[ Indication for Slow and Fast rotation ]
            g.DrawString("SLOW", new Font("Arial", 22), Brushes.Red, new PointF(centre_x - 130, HEIGHT / 2));
            g.DrawString("FAST", new Font("Arial", 22), Brushes.Green, new PointF(centre_x + 40, HEIGHT / 2));
            #endregion

            #region[ Draw advanced angle depending upon total_delay and frequency diff(slip)]            
            if ((Incoming_Phasor_Frequency - Ref_Phasor_Frequency) >= 0)       //ideally Advanced_Angle should be calculated when incoming phasor frequency >=Reffrequency 
                                                                               //right half of plane                       
            {
                //Using 1st order equation for Advanced angle calculation but 2nd order equation using df/dt values can also be included if necessary depending upon reliable df/dt values.
                Advanced_Angle = (((total_delay / 1000) * 60 * 360 * (Incoming_Phasor_Frequency - Ref_Phasor_Frequency)) / 60);// + (0.5 * ((total_delay/1000) * (total_delay/1000) * 60 * 360 * (dfdt_incoming-dfdt_ref)) / 60); 
                xnew = centre_x + (int)(150 * -Math.Sin(Math.PI * Advanced_Angle / 180));
                ynew = centre_y - (int)(150 * Math.Cos(Math.PI * Advanced_Angle / 180));
            }
            else      //left half of plane
            {
                Advanced_Angle = (((total_delay / 1000) * 60 * 360 * (Ref_Phasor_Frequency - Incoming_Phasor_Frequency)) / 60);// + (0.5*((total_delay/1000)*(total_delay/1000) * 60 * 360 * (dfdt_ref - dfdt_incoming)) / 60); 
                xnew = centre_x - (int)(150 * -Math.Sin(Math.PI * Advanced_Angle / 180));
                ynew = centre_y - (int)(150 * Math.Cos(Math.PI * Advanced_Angle / 180));
            }

            rev = (int)(Advanced_Angle / 360);
            Advanced_Angle = Advanced_Angle - rev * 360;

            Pen p3 = new Pen(Color.Red, 5);
            p3.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(p3, new Point(centre_x, centre_y), new Point(xnew, ynew));

            #endregion

            #region[ To find out and depict adjusted window including total_delays ]

            //When Incoming Frequency> Ref_Phasor_Frequency
            if ((Incoming_Phasor_Frequency - Ref_Phasor_Frequency) >= 0)
            {
                allowed_inititation_angle = 360 - (phaseangle_tolerance + Advanced_Angle);
                if (Advanced_Angle >= phaseangle_tolerance)
                {
                    allowed_termination_angle = 360 + phaseangle_tolerance - Advanced_Angle;
                }
                else
                {

                    allowed_termination_angle = (phaseangle_tolerance - Advanced_Angle);
                }
            }
            //When Incoming Frequency< Ref_Phasor_Frequency
            else
            {
                allowed_inititation_angle = phaseangle_tolerance + Advanced_Angle;
                if (Advanced_Angle >= phaseangle_tolerance)
                {
                    allowed_termination_angle = Advanced_Angle - phaseangle_tolerance;
                }
                else
                {
                    allowed_termination_angle = 360 - phaseangle_tolerance + Advanced_Angle;
                }
            }

            //Depict allowed breaker closing adjusted window after total_delay
            x_start = centre_x - (int)(150 * -Math.Sin(Math.PI * allowed_inititation_angle / 180));
            y_start = centre_y - (int)(150 * Math.Cos(Math.PI * allowed_inititation_angle / 180));
            g.DrawLine(new Pen(Color.SlateGray, 5), new Point(centre_x, centre_y), new Point(x_start, y_start));

            x_end = centre_x - (int)(150 * -Math.Sin(Math.PI * allowed_termination_angle / 180));
            y_end = centre_y - (int)(150 * Math.Cos(Math.PI * allowed_termination_angle / 180));
            g.DrawLine(new Pen(Color.SlateGray, 5), new Point(centre_x, centre_y), new Point(x_end, y_end));

            //Depict Advanced_Angle value in respective textbox
            advanceAngleTextBox.Text = Advanced_Angle.ToString("c").Remove(0, 1);
            #endregion

            #region [Voltage and frequency Checklist indication]
            //indication of frequency requirements
            if (Math.Abs(Incoming_Phasor_Frequency - Ref_Phasor_Frequency) <= frequency_tolerance)
            {
                g.FillRectangle(new SolidBrush(Color.PaleGreen), centre_x - 180, HEIGHT - 20, 50, 25);
            }
            else { g.FillRectangle(new SolidBrush(Color.Salmon), centre_x - 180, HEIGHT - 20, 50, 25); }

            //indication of voltage requirements
            if (Math.Abs(Incoming_Phasor_Voltage - Ref_Phasor_Voltage) / Ref_Phasor_Voltage <= Vmag_tolerance)
            {
                g.FillRectangle(new SolidBrush(Color.PaleGreen), centre_x + 130, HEIGHT - 20, 50, 25);
            }
            else { g.FillRectangle(new SolidBrush(Color.Salmon), centre_x + 130, HEIGHT - 20, 50, 25); }


            g.DrawString("Freq", new Font("Arial", 12), Brushes.Black, new PointF(centre_x - 180, HEIGHT - 20));
            g.DrawString("Vmag", new Font("Arial", 12), Brushes.Black, new PointF(centre_x + 130, HEIGHT - 20));
            #endregion

            #region[Auto mode operation]
            if (auto == true)
            {
                //In Auto mode the breaker close command should only be initiated at Advanced_Angle position with 3 degree buffer 
                if (Incoming_Phasor_Frequency >= Ref_Phasor_Frequency)
                {
                    allowed_inititation_angle = 360 - (Advanced_Angle+3);  //forward sync
                }
                else
                {
                    allowed_inititation_angle = (Advanced_Angle+3);  //reverse sync
                }
                breakerCloseButton.PerformClick();
            }
            #endregion

            #region[CB_status indication at the center]
            if (breaker_status == true)
            {
                g.FillEllipse(new SolidBrush(Color.Red), centre_x - 30, centre_y - 30, WIDTH / 5, HEIGHT / 5);
                g.DrawEllipse(p, centre_x - 30, centre_y - 30, WIDTH / 5, HEIGHT / 5);
            }
            else
            {
                g.FillEllipse(new SolidBrush(Color.Green), centre_x - 30, centre_y - 30, WIDTH / 5, HEIGHT / 5);
                g.DrawEllipse(p, centre_x - 30, centre_y - 30, WIDTH / 5, HEIGHT / 5);
            }
            #endregion

            //load bitmap in picturebox1
            SynchroscopePictureBox.Image = bmp;

            #region[Update the Angular Position(for between frames) before Synchronization]
            if (breaker_status == false)
            {
                if (Incoming_Phasor_Frequency >= Ref_Phasor_Frequency)
                {
                    Angular_position++;        //As for each tick time interval is set in such a way that angle should increase or decrease by 1degree         
                }
                else
                {
                    Angular_position--;
                }
            }

            if (Angular_position == 360)
            {
                Angular_position = 0;
            }
            #endregion
        }

        //Receive current updated frame of measurements and use it to generate the o/p measurements 
        public void Update_measurements(out bool CB_close, out bool CB_open)
        {
            #region[Assign data to variables]

            dfdt_ref = Algorithm.inputData.Roc_Reference_phasor;      //ROC of Refphasor frequency
            dfdt_incoming = Algorithm.inputData.Roc_incoming_phasor;   //ROC of Incoming phasor frequency
            Incoming_Phasor_Frequency =  Algorithm.inputData.test_Incoming_freq;   //Incoming phasor frequency 
            Ref_Phasor_Frequency =  Algorithm.inputData.test_Reference_freq;      //Reference phasor frequency
            Incoming_Phasor_Voltage = Algorithm.inputData.test_VoltMag1 ;        //Incoming Phasor V_mag in V
            Ref_Phasor_Voltage = Algorithm.inputData.test_VoltMag2 ;            //Reference Phasor V_mag in V
            if (Algorithm.inputData.test_CB_status == 0)                  //Breaker status from openECA
            {
                breaker_status = false;
            }
            else
            {
                breaker_status = true;
            }
            Incoming_phasor_angle = Algorithm.inputData.test_VoltAng1;
            Ref_phasor_angle = Algorithm.inputData.test_VoltAng2;
            Angular_position = Incoming_phasor_angle- Ref_phasor_angle ;

            //For the functinality of the analytic as Angular_position can vary from 0 to 360 only and can't have negative values  
            if (Angular_position <= 0)
            {
                Angular_position = 360 + Angular_position;
            }
            
            if (breaker_status == true)
            {
                breaker_close_command = false;
            }
            else
            {
                breaker_open_command = false;
            }
            #endregion

            #region[breaker buttons indication]

            if (breaker_close_command == false && breaker_open_command == true)
            {
                breakerOpenButton.BackColor = Color.Green;
                breakerCloseButton.BackColor = Color.Empty;
            }
            else if (breaker_close_command == true && breaker_open_command == false)
            {
                breakerCloseButton.BackColor = Color.Red;
                breakerOpenButton.BackColor = Color.Empty;

            }
            else
            {
                breakerCloseButton.BackColor = Color.Empty;
                breakerOpenButton.BackColor = Color.Empty;
            }
            #endregion

            #region[Textbox values Updation]
            //Textbox Values representation
            voltageIncomingPhasorTextBox.Text = Convert.ToString(Math.Ceiling(Incoming_Phasor_Voltage / 10) / 100);
            voltageReferencePhasorTextBox.Text = Convert.ToString(Math.Ceiling(Ref_Phasor_Voltage / 10) / 100);
            IncomingVangTextbox.Text = Convert.ToString(Math.Ceiling(Incoming_phasor_angle * 100) / 100);
            RefAngtextbox.Text = Convert.ToString(Math.Ceiling(Ref_phasor_angle * 100) / 100);
            freqIncomingPhasorTextBox.Text = Convert.ToString(Math.Ceiling(Incoming_Phasor_Frequency * 100) / 100);
            freqReferencePhasorTextBox.Text = Convert.ToString((Math.Ceiling(Ref_Phasor_Frequency * 100)) / 100);
            #endregion

            #region[ Alarm boxes]
            if (Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency) <= frequency_tolerance)
            {
                Freq_Alarm_Box.Text = "Within Limits :No Action Necessary";
                freqRaiseButton.BackColor = default(Color);
                freqLowerButton.BackColor = default(Color);
            }
            else if (Incoming_Phasor_Frequency >= Ref_Phasor_Frequency)
            {
                Freq_Alarm_Box.Text = "Lower By " + (Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency)).ToString("c").Remove(0, 1) + " Hz";
                freqLowerButton.BackColor = Color.Red;
                freqRaiseButton.BackColor = default(Color);
            }
            else
            {
                Freq_Alarm_Box.Text = "Raise By " + (Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency)).ToString("c").Remove(0, 1) + " Hz";
                freqLowerButton.BackColor = default(Color);
                freqRaiseButton.BackColor = Color.Red;
            }

            if (Math.Abs(Ref_Phasor_Voltage - Incoming_Phasor_Voltage) / (Ref_Phasor_Voltage) <= Vmag_tolerance)  
            {
                Vmag_Alarm_Box.Text = "Within Limits :No Action Necessary";
                voltageMagLowerButton.BackColor = default(Color);
                voltageMagRaiseButton.BackColor = default(Color);
            }
            else if (Incoming_Phasor_Voltage >= Ref_Phasor_Voltage)
            {
                Vmag_Alarm_Box.Text = "Lower By " + (Math.Abs(Ref_Phasor_Voltage - Incoming_Phasor_Voltage) / 1000).ToString("c").Remove(0, 1) + " KV";
                voltageMagRaiseButton.BackColor = default(Color);
                voltageMagLowerButton.BackColor = Color.Red;
            }
            else
            {
                Vmag_Alarm_Box.Text = "Raise by " + (Math.Abs(Ref_Phasor_Voltage - Incoming_Phasor_Voltage) / 1000).ToString("c").Remove(0, 1) + " KV";
                voltageMagLowerButton.BackColor = default(Color);
                voltageMagRaiseButton.BackColor = Color.Red;
            }
            #endregion

            #region[ Start the graphs once data starts streaming in]
            if (!incomingDataStarted)
            {
                incomingDataStarted = true;
                startgraphs();
            }
            #endregion

            TimeIntervalupdate();       //call this function to update time interval for smooth transition
                                        //for depiction between two frames

            CB_close = breaker_close_command;          //return breaker Commands  
            CB_open = breaker_open_command;
        }
   
        //Update the time interval to be used between two consecutive frames
        public void TimeIntervalupdate()
        {
            if (Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency) < (1000/360)) //in other words, t.interval should not be less than 1 ms
            {
                if (Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency) < 0.01)
                {
                    t.Interval = 277;      //if slip is very minimal(<0.01 Hz) we assign a significantly large value to make the phasormag hand stop
                                           //because following the formula gives t.Interval is nearly equal to infinity . 
                }
                else
                {
                    t.Interval = Convert.ToInt32(1000 / (360 * Math.Abs(Ref_Phasor_Frequency - Incoming_Phasor_Frequency)));   //in milliseconds
                }
            }
            else
            {
                t.Interval = 1;
            }                        
            if (t.Interval >= Convert.ToInt32(refresh_time))
            {
                t.Interval = Convert.ToInt32(refresh_time);     //Use refresh time as image should be refreshed within this time period at max.
            }
        }
    }
}