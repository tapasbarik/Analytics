﻿// ************************************************************************************************************
//************************************openECA Project-PMU_Synchroscope Analytic********************************
//Code for a remote synchrophasor based synchroscope analytic as a part of the openECA project sponsored by DOE
//Project Partners:Dominion Virginia Power
//                 Virginia Tech
//                 Grid Protection Alliance
//Developer-Tapas Kumar Barik
//File:Algorithm.cs
//Inputs:Voltage phasors(both magnitude and angle),frequency,and ROC of frequency from two remote buses to be 
//       synchronized on two separate islands from the openECA platform.
//Output:output in form of CB_out which is an analog value (5 volts if the command to the synchronizing breaker
//       is initiated after all the requirements are satisfied, otherwise 0 volts).
//*************************************************************************************************************

using System;
using ECAClientFramework;
using ECAClientUtilities.API;
using PMU_Synchroscope.Model.GPA;
using System.Windows.Forms;


namespace PMU_Synchroscope
{
    public static class Algorithm
    {
        public static Hub API { get; set; }
        public static test_DataIn inputData;
        public static DateTime input_time_stamp = new DateTime();
        public static double timespan_inputdelay;
        public static Synchroscope_Form syncForm;
        public static bool breaker_close_command = false;
        public static bool breaker_open_command = false;

        public class Output
        {
            public test_DataOut OutputData = new test_DataOut();
            public _test_DataOutMeta OutputMeta = new _test_DataOutMeta();
            public static Func<Output> CreateNew { get; set; } = () => new Output();
        }

        public static void UpdateSystemSettings()
        {
            SystemSettings.InputMapping = "Map_in";
            SystemSettings.OutputMapping = "Map_Out";
            SystemSettings.ConnectionString = @"server=localhost:6190; interface=0.0.0.0";
            SystemSettings.FramesPerSecond = 30;
            SystemSettings.LagTime = 0.5;
            SystemSettings.LeadTime = 0.5;
        }

        public static void Check_criteria_for_updation()
        {
            if (syncForm.InvokeRequired)
                syncForm.Invoke((MethodInvoker)delegate ()
                {
                    Check_criteria_for_updation();
                });
            else
            {
                syncForm.Update_measurements(out breaker_close_command, out breaker_open_command);
            }
        }

        public static Output Execute(test_DataIn inputData, _test_DataInMeta inputMeta)
        {
            Output output = Output.CreateNew();
            Algorithm.inputData = inputData;
            try
            {
                MainWindow.WriteMessage("PMU Synchroscope Framework receiving Data");             
                input_time_stamp = inputMeta.test_VoltAng1.Timestamp;
                timespan_inputdelay = (DateTime.UtcNow - input_time_stamp).TotalMilliseconds;
                MainWindow.WriteMessage("Input Delay: " + Convert.ToString(Algorithm.input_time_stamp) + "--------------------" + Convert.ToString(DateTime.UtcNow) + "----------" + Convert.ToString(timespan_inputdelay));

                Algorithm.Check_criteria_for_updation();
                #region[Assign values to O/P measurements]
                if (breaker_close_command == false)
                {
                    output.OutputData.CB_close = 0;         //Zero Volts
                }
                else
                {
                    output.OutputData.CB_close = 5;         //Five Volts for signal
                }
                if (breaker_open_command == false)
                {
                    output.OutputData.CB_open = 0;
                }
                else
                {
                    output.OutputData.CB_open = 5;
                }
                #endregion

            }
            catch (Exception ex)
            {
                // Display exceptions to the main window
                MainWindow.WriteError(new InvalidOperationException($"Algorithm exception: {ex.Message}", ex));
            }
            return output;
        }
    }
}
