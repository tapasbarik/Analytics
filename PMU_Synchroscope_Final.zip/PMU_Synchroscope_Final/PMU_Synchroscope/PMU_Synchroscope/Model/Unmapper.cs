﻿// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using ECAClientFramework;
using ECAClientUtilities;
using ECACommonUtilities;
using ECACommonUtilities.Model;
using GSF.TimeSeries;

namespace PMU_Synchroscope.Model
{
    [CompilerGenerated]
    public class Unmapper : UnmapperBase
    {
        #region [ Constructors ]

        public Unmapper(Framework framework, MappingCompiler mappingCompiler)
            : base(framework, mappingCompiler, SystemSettings.OutputMapping)
        {
            Algorithm.Output.CreateNew = () => new Algorithm.Output()
            {
                OutputData = FillOutputData(),
                OutputMeta = FillOutputMeta()
            };
        }

        #endregion

        #region [ Methods ]

        public PMU_Synchroscope.Model.GPA.test_DataOut FillOutputData()
        {
            TypeMapping outputMapping = MappingCompiler.GetTypeMapping(OutputMapping);
            Reset();
            return FillGPAtest_DataOut(outputMapping);
        }

        public PMU_Synchroscope.Model.GPA._test_DataOutMeta FillOutputMeta()
        {
            TypeMapping outputMeta = MappingCompiler.GetTypeMapping(OutputMapping);
            Reset();
            return FillGPA_test_DataOutMeta(outputMeta);
        }

        public IEnumerable<IMeasurement> Unmap(PMU_Synchroscope.Model.GPA.test_DataOut outputData, PMU_Synchroscope.Model.GPA._test_DataOutMeta outputMeta)
        {
            List<IMeasurement> measurements = new List<IMeasurement>();
            TypeMapping outputMapping = MappingCompiler.GetTypeMapping(OutputMapping);

            CollectFromGPAtest_DataOut(measurements, outputMapping, outputData, outputMeta);

            return measurements;
        }

        private PMU_Synchroscope.Model.GPA.test_DataOut FillGPAtest_DataOut(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            PMU_Synchroscope.Model.GPA.test_DataOut obj = new PMU_Synchroscope.Model.GPA.test_DataOut();

            {
                // We don't need to do anything, but we burn a key index to keep our
                // array index in sync with where we are in the data structure
                BurnKeyIndex();
            }

            {
                // We don't need to do anything, but we burn a key index to keep our
                // array index in sync with where we are in the data structure
                BurnKeyIndex();
            }

            return obj;
        }

        private PMU_Synchroscope.Model.GPA._test_DataOutMeta FillGPA_test_DataOutMeta(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            PMU_Synchroscope.Model.GPA._test_DataOutMeta obj = new PMU_Synchroscope.Model.GPA._test_DataOutMeta();

            {
                // Initialize meta value structure to "CB_close" field
                FieldMapping fieldMapping = fieldLookup["CB_close"];
                obj.CB_close = CreateMetaValues(fieldMapping);
            }

            {
                // Initialize meta value structure to "CB_open" field
                FieldMapping fieldMapping = fieldLookup["CB_open"];
                obj.CB_open = CreateMetaValues(fieldMapping);
            }

            return obj;
        }

        private void CollectFromGPAtest_DataOut(List<IMeasurement> measurements, TypeMapping typeMapping, PMU_Synchroscope.Model.GPA.test_DataOut data, PMU_Synchroscope.Model.GPA._test_DataOutMeta meta)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);

            {
                // Convert value from "CB_close" field to measurement
                FieldMapping fieldMapping = fieldLookup["CB_close"];
                IMeasurement measurement = MakeMeasurement(meta.CB_close, (double)data.CB_close);
                measurements.Add(measurement);
            }

            {
                // Convert value from "CB_open" field to measurement
                FieldMapping fieldMapping = fieldLookup["CB_open"];
                IMeasurement measurement = MakeMeasurement(meta.CB_open, (double)data.CB_open);
                measurements.Add(measurement);
            }
        }

        #endregion
    }
}
