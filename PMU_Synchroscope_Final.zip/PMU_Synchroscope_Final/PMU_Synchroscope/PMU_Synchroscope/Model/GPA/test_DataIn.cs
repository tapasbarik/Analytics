// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;

namespace PMU_Synchroscope.Model.GPA
{
    [CompilerGenerated]
    public partial class test_DataIn
    {
        public double test_VoltMag1 { get; set; }
        public double test_VoltAng1 { get; set; }
        public double test_VoltMag2 { get; set; }
        public double test_VoltAng2 { get; set; }
        public double test_Incoming_freq { get; set; }
        public double test_Reference_freq { get; set; }
        public double Roc_incoming_phasor { get; set; }
        public double Roc_Reference_phasor { get; set; }
        public double test_CB_status { get; set; }
    }
}