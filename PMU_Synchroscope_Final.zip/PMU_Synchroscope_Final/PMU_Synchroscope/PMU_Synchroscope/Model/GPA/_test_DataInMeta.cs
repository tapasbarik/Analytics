// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;
using ECAClientFramework;

namespace PMU_Synchroscope.Model.GPA
{
    [CompilerGenerated]
    public partial class _test_DataInMeta
    {
        public MetaValues test_VoltMag1 { get; set; }
        public MetaValues test_VoltAng1 { get; set; }
        public MetaValues test_VoltMag2 { get; set; }
        public MetaValues test_VoltAng2 { get; set; }
        public MetaValues test_Incoming_freq { get; set; }
        public MetaValues test_Reference_freq { get; set; }
        public MetaValues Roc_incoming_phasor { get; set; }
        public MetaValues Roc_Reference_phasor { get; set; }
        public MetaValues test_CB_status { get; set; }
    }
}