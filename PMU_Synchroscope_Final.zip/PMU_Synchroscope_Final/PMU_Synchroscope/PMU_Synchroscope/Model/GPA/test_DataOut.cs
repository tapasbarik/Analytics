// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;

namespace PMU_Synchroscope.Model.GPA
{
    [CompilerGenerated]
    public partial class test_DataOut
    {
        public double CB_close { get; set; }
        public double CB_open { get; set; }
    }
}