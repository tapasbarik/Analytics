// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;
using ECAClientFramework;

namespace PMU_Synchroscope.Model.GPA
{
    [CompilerGenerated]
    public partial class _test_DataOutMeta
    {
        public MetaValues CB_close { get; set; }
        public MetaValues CB_open { get; set; }
    }
}