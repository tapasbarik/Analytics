﻿// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using ECAClientFramework;
using ECAClientUtilities;
using ECACommonUtilities;
using ECACommonUtilities.Model;
using GSF.TimeSeries;

namespace PMU_Synchroscope.Model
{
    [CompilerGenerated]
    public class Mapper : MapperBase
    {
        #region [ Members ]

        // Fields
        private readonly Unmapper m_unmapper;

        #endregion

        #region [ Constructors ]

        public Mapper(Framework framework)
            : base(framework, SystemSettings.InputMapping)
        {
            m_unmapper = new Unmapper(framework, MappingCompiler);
            Unmapper = m_unmapper;
        }

        #endregion

        #region [ Methods ]

        public override void Map(IDictionary<MeasurementKey, IMeasurement> measurements)
        {
            SignalLookup.UpdateMeasurementLookup(measurements);
            TypeMapping inputMapping = MappingCompiler.GetTypeMapping(InputMapping);

            Reset();
            PMU_Synchroscope.Model.GPA.test_DataIn inputData = CreateGPAtest_DataIn(inputMapping);
            Reset();
            PMU_Synchroscope.Model.GPA._test_DataInMeta inputMeta = CreateGPA_test_DataInMeta(inputMapping);

            Algorithm.Output algorithmOutput = Algorithm.Execute(inputData, inputMeta);
            Subscriber.SendMeasurements(m_unmapper.Unmap(algorithmOutput.OutputData, algorithmOutput.OutputMeta));
        }

        private PMU_Synchroscope.Model.GPA.test_DataIn CreateGPAtest_DataIn(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            PMU_Synchroscope.Model.GPA.test_DataIn obj = new PMU_Synchroscope.Model.GPA.test_DataIn();

            {
                // Assign double value to "test_VoltMag1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag1 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltAng1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng1 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltMag2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag2 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltAng2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng2 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_Incoming_freq" field
                FieldMapping fieldMapping = fieldLookup["test_Incoming_freq"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_Incoming_freq = (double)measurement.Value;
            }

            {
                // Assign double value to "test_Reference_freq" field
                FieldMapping fieldMapping = fieldLookup["test_Reference_freq"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_Reference_freq = (double)measurement.Value;
            }

            {
                // Assign double value to "Roc_incoming_phasor" field
                FieldMapping fieldMapping = fieldLookup["Roc_incoming_phasor"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.Roc_incoming_phasor = (double)measurement.Value;
            }

            {
                // Assign double value to "Roc_Reference_phasor" field
                FieldMapping fieldMapping = fieldLookup["Roc_Reference_phasor"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.Roc_Reference_phasor = (double)measurement.Value;
            }

            {
                // Assign double value to "test_CB_status" field
                FieldMapping fieldMapping = fieldLookup["test_CB_status"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_CB_status = (double)measurement.Value;
            }

            return obj;
        }

        private PMU_Synchroscope.Model.GPA._test_DataInMeta CreateGPA_test_DataInMeta(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            PMU_Synchroscope.Model.GPA._test_DataInMeta obj = new PMU_Synchroscope.Model.GPA._test_DataInMeta();

            {
                // Assign MetaValues value to "test_VoltMag1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag1 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltAng1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng1 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltMag2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag2 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltAng2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng2 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_Incoming_freq" field
                FieldMapping fieldMapping = fieldLookup["test_Incoming_freq"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_Incoming_freq = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_Reference_freq" field
                FieldMapping fieldMapping = fieldLookup["test_Reference_freq"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_Reference_freq = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "Roc_incoming_phasor" field
                FieldMapping fieldMapping = fieldLookup["Roc_incoming_phasor"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.Roc_incoming_phasor = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "Roc_Reference_phasor" field
                FieldMapping fieldMapping = fieldLookup["Roc_Reference_phasor"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.Roc_Reference_phasor = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_CB_status" field
                FieldMapping fieldMapping = fieldLookup["test_CB_status"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_CB_status = GetMetaValues(measurement);
            }

            return obj;
        }

        #endregion
    }
}
