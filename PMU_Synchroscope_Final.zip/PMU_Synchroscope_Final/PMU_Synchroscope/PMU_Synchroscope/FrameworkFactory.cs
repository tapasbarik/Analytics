﻿using ECAClientFramework;
using PMU_Synchroscope.Model;

namespace PMU_Synchroscope
{
    public static class FrameworkFactory
    {
        public static Framework Create()
        {
            return new Framework(fw => new Mapper(fw));
        }
    }
}