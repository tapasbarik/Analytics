﻿// ************************************************************************************************************
//************************************openECA Project-PMU_Synchroscope Analytic********************************
//Code for the input screen for a remote synchrophasor based synchroscope analytic as a part of the openECA project sponsored by DOE
//Project Partners:Dominion Virginia Power
//                 Virginia Tech
//                 Grid Protection Alliance
//Developer-Tapas Kumar Barik
//File:Input_screen.cs Windows Form Application
//Inputs:User defined Measurement channel IDs and tolerance limits for the functioning of the Synchroscope_Form 
//Output:Framework to be created with Custom defined Mapping files for the functioning of the Synchroscope_Form
//*************************************************************************************************************

using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using ECACommonUtilities;
using ECACommonUtilities.Model;
using ECAClientFramework;
using ECAClientUtilities.API;
using System.Media;
using System.Data.SQLite;

namespace PMU_Synchroscope
{
    public partial class Input_screen : Form
    {
        public Input_screen()
        {
            InitializeComponent();
            Fillcomboboxes();
        }

        #region[Class Fields]
        public static string Text1 = "";
        public static string Text2 = "";
        public static string Text3 = "";
        public static string Text4 = "";
        public static string Text5 = "";
        public static string Text6 = "";
        public static string Text7 = "";
        public static string Text8 = "";
        public static string Text9 = "";
        public static string Text10 = "";
        public static string Text11 = "";
        public static double freq_limit;
        public static double Vmag_limit;
        public static double Vang_limit;

        ErrorProvider errorProvider = new ErrorProvider();
        #endregion

        private void Fillcomboboxes()
        {
            string constring = @"Data Source=C:\Program Files\openECA\Server\ConfigurationCache\openECA.db;Version=3";
            SQLiteConnection conDatabase = new SQLiteConnection(constring);
            SQLiteDataReader reader;

            try
            {
                conDatabase.Open();
                string query_freq = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='FREQ' ;";
                SQLiteCommand cmd_freq = new SQLiteCommand(query_freq, conDatabase);
                reader = cmd_freq.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox1.Items.Add(sSR);
                    comboBox5.Items.Add(sSR);
                }

                string query_Vmag = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='VPHM' ;";
                SQLiteCommand cmd_Vmag = new SQLiteCommand(query_Vmag, conDatabase);
                reader = cmd_Vmag.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox2.Items.Add(sSR);
                    comboBox6.Items.Add(sSR);
                }

                string query_Vang = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='VPHA' ;";
                SQLiteCommand cmd_Vang = new SQLiteCommand(query_Vang, conDatabase);
                reader = cmd_Vang.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox3.Items.Add(sSR);
                    comboBox7.Items.Add(sSR);
                }

                string query_ROCF = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='DFDT' ;";
                SQLiteCommand cmd_ROCF = new SQLiteCommand(query_ROCF, conDatabase);
                reader = cmd_ROCF.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox4.Items.Add(sSR);
                    comboBox8.Items.Add(sSR);
                }

                string query_CBstatus = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='DIGI' ;";
                SQLiteCommand cmd_CBstatus = new SQLiteCommand(query_CBstatus, conDatabase);
                reader = cmd_CBstatus.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox9.Items.Add(sSR);
                }

                string query_CBclose = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='VPHM' ;";
                SQLiteCommand cmd_CBclose = new SQLiteCommand(query_CBclose, conDatabase);
                reader = cmd_CBclose.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox10.Items.Add(sSR);
                }

                string query_CBopen = "SELECT SignalReference FROM ActiveMeasurement WHERE SignalType='VPHM' ;";
                SQLiteCommand cmd_CBopen = new SQLiteCommand(query_CBopen, conDatabase);
                reader = cmd_CBopen.ExecuteReader();
                while (reader.Read())
                {
                    string sSR = reader.GetString(0);
                    comboBox11.Items.Add(sSR);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Input_screen_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.PapayaWhip;
        }

        private void Create_Framework_button_Click(object sender, EventArgs e)
        {
            #region[Connecting the SignalReference to respective Historian IDs]
            string constring = @"Data Source=C:\Program Files\openECA\Server\ConfigurationCache\openECA.db;Version=3";
            SQLiteConnection conDatabase = new SQLiteConnection(constring);
            SQLiteDataReader reader;
            conDatabase.Open();
            
            string query_freq = "SELECT ID,SignalReference FROM ActiveMeasurement WHERE SignalType='FREQ' ;";
            SQLiteCommand cmd_freq = new SQLiteCommand(query_freq, conDatabase);
            reader = cmd_freq.ExecuteReader();
            while (reader.Read())
            {
                if (comboBox1.Text == reader.GetString(1))
                    Text1 = reader.GetString(0);
                if (comboBox5.Text == reader.GetString(1))
                    Text5= reader.GetString(0);
            }
            string query_Vmag = "SELECT ID,SignalReference FROM ActiveMeasurement WHERE SignalType='VPHM' ;";
            SQLiteCommand cmd_Vmag = new SQLiteCommand(query_Vmag, conDatabase);
            reader = cmd_Vmag.ExecuteReader();
            while (reader.Read())
            {
                if (comboBox2.Text == reader.GetString(1))
                    Text2 = reader.GetString(0);
                if (comboBox6.Text == reader.GetString(1))
                    Text6 = reader.GetString(0);
                if (comboBox10.Text == reader.GetString(1))
                    Text10 = reader.GetString(0);
                if (comboBox11.Text == reader.GetString(1))
                    Text11 = reader.GetString(0);
            }
            string query_Vang = "SELECT ID,SignalReference FROM ActiveMeasurement WHERE SignalType='VPHA' ;";
            SQLiteCommand cmd_Vang = new SQLiteCommand(query_Vang, conDatabase);
            reader = cmd_Vang.ExecuteReader();
            while (reader.Read())
            {
                if (comboBox3.Text == reader.GetString(1))
                    Text3 = reader.GetString(0);
                if (comboBox7.Text == reader.GetString(1))
                    Text7 = reader.GetString(0);
            }
            string query_ROCF = "SELECT ID,SignalReference FROM ActiveMeasurement WHERE SignalType='DFDT' ;";
            SQLiteCommand cmd_ROCF = new SQLiteCommand(query_ROCF, conDatabase);
            reader = cmd_ROCF.ExecuteReader();
            while (reader.Read())
            {
                if (comboBox4.Text == reader.GetString(1))
                    Text4 = reader.GetString(0);
                if (comboBox8.Text == reader.GetString(1))
                    Text8 = reader.GetString(0);
            }
            string query_CBstatus = "SELECT ID,SignalReference FROM ActiveMeasurement WHERE SignalType='DIGI' ;";
            SQLiteCommand cmd_CBstatus = new SQLiteCommand(query_CBstatus, conDatabase);
            reader = cmd_CBstatus.ExecuteReader();
            while (reader.Read())
            {
                if (comboBox9.Text == reader.GetString(1))
                    Text9 = reader.GetString(0);
            }
            #endregion

            List<ComboBox> comboboxes = new List<ComboBox>();
            for (int i = 1; i <= 11; i++)
            {
                comboboxes.Add((ComboBox)this.Controls.Find("ComboBox" + Convert.ToString(i), true)[0]);
            }
            bool null_data = false;
            for (int i = 0; i < 11; i++)
            {
                comboboxes[i].BackColor = default(Color);
                if (string.IsNullOrWhiteSpace(comboboxes[i].Text))
                {
                    null_data = true;
                    comboboxes[i].Focus();
                    comboboxes[i].BackColor = Color.LightSalmon;
                }
            }
            SoundPlayer player = new SoundPlayer();
            if (null_data == true)
            {
                player.SoundLocation = @"C:\WINDOWS\Media\Windows Error.wav";
                player.Play();
                MessageBox.Show("Enter ID for all the highlighted fields", "Error Information");
            }
            else
            {
                player.SoundLocation = @"C:\WINDOWS\Media\Windows Notify.wav";
                player.Play();

                MakeMappings();
                var MainWindow_thread = new Thread(ThreadStart_for_main_window);
                MainWindow_thread.TrySetApartmentState(ApartmentState.STA);
                MainWindow_thread.Start();
            }
        }

        private static void MakeMappings()
        {
            UDTCompiler udtCompiler = new UDTCompiler();
            udtCompiler.Compile("Model\\UserDefinedTypes.ecaidl");

            UserDefinedType test_DataIn = (UserDefinedType)udtCompiler.GetType("test_DataIn");
            Dictionary<string, UDTField> test_DataInFields = test_DataIn.Fields.ToDictionary(field => field.Identifier);

            UserDefinedType test_DataOut = (UserDefinedType)udtCompiler.GetType("test_DataOut");
            Dictionary<string, UDTField> test_DataOutFields = test_DataOut.Fields.ToDictionary(field => field.Identifier);
            // Create mapping
            TypeMapping input_map = new TypeMapping();

            input_map.Type = test_DataIn;
            input_map.Identifier = "Map_in";

            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_VoltMag1"],
                Expression = Text2
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_VoltAng1"],
                Expression = Text3
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_VoltMag2"],
                Expression = Text6
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_VoltAng2"],
                Expression = Text7
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_Incoming_freq"],
                Expression = Text1
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_Reference_freq"],
                Expression = Text5
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["Roc_incoming_phasor"],
                Expression = Text4
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["Roc_Reference_phasor"],
                Expression = Text8
            });
            input_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataInFields["test_CB_status"],
                Expression = Text9
            });

            TypeMapping output_map = new TypeMapping();

            output_map.Type = test_DataOut;
            output_map.Identifier = "Map_Out";

            output_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataOutFields["CB_close"],
                Expression = Text10
            });
            output_map.FieldMappings.Add(new FieldMapping()
            {
                Field = test_DataOutFields["CB_open"],
                Expression = Text11
            });
            // Add new mappings to the MappingWriter
            // and write the results to a file
            MappingWriter writer = new MappingWriter();
            writer.Mappings.Add(input_map);
            writer.Mappings.Add(output_map);
            writer.Write(Path.GetFullPath("Model\\UserDefinedMappings.ecamap"));
        }

        private static void ThreadStart_for_main_window()
        {
            Algorithm.UpdateSystemSettings();
            Framework framework = FrameworkFactory.Create();
            Algorithm.API = new Hub(framework);
            MainWindow mainWindow = new MainWindow(framework);
            mainWindow.Text = "C# PMU_Synchroscope Analytic";
            Application.Run(mainWindow);
        }

        private void Enter_button_Click(object sender, EventArgs e)
        {
            try
            {
                freq_limit = Convert.ToDouble(textBox12.Text);
                Vmag_limit = Convert.ToDouble(textBox13.Text);
                Vang_limit = Convert.ToDouble(textBox14.Text);

                var Synchroscope_thread = new Thread(ThreadStart_forsynchroscope);
                Synchroscope_thread.TrySetApartmentState(ApartmentState.STA);
                Synchroscope_thread.Start();
            }
            catch (Exception ex)
            {
                SoundPlayer player = new SoundPlayer();
                player.SoundLocation = @"C:\WINDOWS\Media\Windows Error.wav";
                player.Play();
                MessageBox.Show(ex.Message, "Error Information");
            }
        }

        private static void ThreadStart_forsynchroscope()
        {
            Algorithm.syncForm = new Synchroscope_Form();
            Application.Run(Algorithm.syncForm); // <-- other form started on its own UI thread
        }
    }
}
