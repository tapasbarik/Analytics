using System;
using ECAClientFramework;
using VoltageInput_Synch.Model.GPA;
using System.Windows.Forms;

namespace VoltageInput_Synch
{
    static class Algorithm
    {
        public static test_DataIn inputData;
        internal class Output
        {
            test_DataOut OutputData = new test_DataOut();
            _test_DataOutMeta OutputMeta = new _test_DataOutMeta();
        }

        public static void UpdateSystemSettings()
        {
            SystemSettings.ConnectionString = @"server=localhost:6190; interface=0.0.0.0";
            SystemSettings.FramesPerSecond = 60;
            SystemSettings.LagTime = 3;
            SystemSettings.LeadTime = 1;
        }
        public static void updateForm()
        {
            if (Program.syncForm.InvokeRequired)
                Program.syncForm.Invoke((MethodInvoker)delegate ()
                {
                    updateForm();
                });
            else Program.syncForm.updateSynchronousForm();
        }

        public static Output Execute(test_DataIn inputData, _test_DataInMeta inputMeta)
        {
            Output output = new Output();
            Algorithm.inputData = inputData;
            try
            {
                Algorithm.updateForm();
                
            }
            catch (Exception ex)
            {
                // Display exceptions to the main window
                MainWindow.WriteError(new InvalidOperationException($"Algorithm exception: {ex.Message}", ex));
            }

            return output;
        }
    }
}
