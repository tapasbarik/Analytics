﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace VoltageInput_Synch
{
    public partial class synchroscopeForm : Form
    {
        Timer t = new Timer();
        #region[Class fields]
        //Tolerance Limits
        const int phaseangle_tolerance=15;      //Phase Angle tolerance in degrees i.e +15/-15 degrees
        double frequency_tolerance = 0.067;     //Frequency_tolerance(maximum slip allowed) in Hz.
        double Vmag_tolerance=0.05;             //Voltage Magnitude tolerance in pu i.e. 0.95 pu to 1.05 p.u.
        double delay = 500;   //in ms

        //System data
        
        double RefFrequency = 60.0;
        double phasorFrequency = 60.2;
        double RefMag = 345;

        int count = 0;
        int WIDTH = 300, HEIGHT = 300;          //size and dimensions of bitmap
        int phasorMag = 150;                    //Initial V_mag size as per limitations
        double phasorvolt, Adv_angle;           //Adv_angle is a function of slip frequency and delay introduced 
        double u, u_initiated, u_adjusted, allowed_inititation_angle, allowed_termination_angle;  //in degrees
        int cx, cy;     //center of the circle
        int x, y;       //phasorMag coordinate
        int xnew, ynew,x_start,y_start,x_end,y_end;
        bool freq = true;       //freq boolean variable is a condition which is true if phasorFrequency>=RefFrequency
        bool breaker = false;   //breaker boolean variable is a condition which is true if only the breaker close command is accepted by the 
                                //algorithm and passed on to control units
        bool auto = false;      //boolean variable to depict if Auto mode is on or not
        Pen p;
        Graphics g;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void IncomingVangTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void RefAngtextbox_TextChanged(object sender, EventArgs e)
        {

        }

        Bitmap bmp;
        #endregion

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void autoModeButton_Click(object sender, EventArgs e)
        {
            auto = true;
            

        }

        private void manualModeButton_Click(object sender, EventArgs e)
        {
            auto = false;
            
        }

        private void Vmag_Alarm_Box_TextChanged(object sender, EventArgs e)
        {

        }
     
        private void freqLowerButton_Click(object sender, EventArgs e)    //Lower Frequency Button
        {
            phasorFrequency = phasorFrequency - 0.033;            //steps of 0.033 Hz difference
                              
        }
      
        private void freqRaiseButton_Click(object sender, EventArgs e)      //Raise Freq Button
        {
            phasorFrequency = phasorFrequency + 0.033;              //steps of 0.033 Hz difference
            
        }

        private void voltageMagLowerButton_Click(object sender, EventArgs e)      //Lower Voltage Mag Button
        {
            phasorMag = phasorMag - 10;         //!0 due to size of graphics ....later in the algorithm  they have been scaled to Vmag accordingly.
           
        }

        private void voltMagRaiseButton_Click(object sender, EventArgs e)
        {
            
            phasorMag = phasorMag + 10;
           
        }
    
        private void Voltage_Chart_Click(object sender, EventArgs e)
        {

        }

        #region [Breaker close logic ]
        private void breakerCloseButton_Click(object sender, EventArgs e)      //close Breaker
        {
           

            //Ideally phasorFrequency should be greater than Reffrequency so as to have power flowing forward.But provision for reverse Synch is also provided.We can remove that as needed.
            //Forward Case
            if (((phasorFrequency - RefFrequency) >= 0 && (phasorFrequency - RefFrequency) <= frequency_tolerance) && (phasorMag <= 180 && phasorMag >= 120))//check for frequency and voltage magnitude tolerance
                {
                if (allowed_inititation_angle>=180 && allowed_termination_angle>=180)
                {
                    if (u>=allowed_inititation_angle && u<=allowed_termination_angle)
                    {
                        breaker = true;             // condition to check breaker command is given and true
                        u_initiated = u;            //angle at which breaker command is given
                        auto = false;
                    }
                }
                else if(allowed_inititation_angle >= 180 && allowed_termination_angle <= 180)
                {
                    if ((u>=allowed_inititation_angle && u<=360)||(u>=0 && u<=allowed_termination_angle))
                    {
                        breaker = true;             // condition to check breaker command is given and true
                        u_initiated = u;            //angle at which breaker command is given
                        auto = false;
                    }
                }
                    
                }
            //Reverse Synch Case
            else if (((phasorFrequency - RefFrequency) < 0 && (RefFrequency - phasorFrequency) <= frequency_tolerance) && (phasorMag <= 180 && phasorMag >= 120))//check for frequency and voltage magnitude tolerance
            {
                if (allowed_inititation_angle <= 180 && allowed_termination_angle <= 180)
                {
                    if ((360-u) <= allowed_inititation_angle && (360-u) >= allowed_termination_angle)
                    {
                        breaker = true;             // condition to check breaker command is given and true
                        u_initiated = u;            //angle at which breaker command is given
                        auto = false;
                    }
                }
                else if (allowed_inititation_angle <= 180 && allowed_termination_angle >= 180)
                {
                    if (((360-u) <= allowed_inititation_angle && (360-u) >= 0) || ((360-u) <= 360 && (360-u) >= allowed_termination_angle))
                    {
                        breaker = true;             // condition to check breaker command is given and true
                        u_initiated = u;            //angle at which breaker command is given
                        auto = false;
                    }
                }

            }
            
        }
        #endregion

        //Open breaker provision would be removed if required as many other conditions have to be checked rather than simply disconnecting
        private void breakerOpenButton_Click(object sender, EventArgs e)      //open Breaker Button
        {
            t.Start();
            breaker = false;        //Reset breaker command boolean variable
            auto = false;           //reset auto mode mode to false as breaker opening is manually done
        }

        public synchroscopeForm()
        {
            InitializeComponent();
        }

        private void synchroscopeForm_Load(object sender, EventArgs e)
        {
            //create Bitmap
            bmp = new Bitmap(WIDTH + 70, HEIGHT + 70);

            //background color
            this.BackColor = Color.SeaShell;

            //center
            cx = WIDTH / 2 +35;
            cy = HEIGHT / 2 +35;

            //Also we have to include where to start as we have to see the zero crossing of both waveforms and then start from that particular angle
            //otherwise synchronization may look like done at 12 o'clock position but in reality may be much different.So u in reality would be
            //phase angle difference between Incoming phasor and reference phasor.
            
            //Here we start the application from zero degree initially
            //Initial degree of HAND
            u=0;            
            //Timer

            if (Math.Abs(phasorFrequency - RefFrequency) < 0.005)
            {
                t.Interval = 10000000;
            }
            else
            {
                t.Interval = Convert.ToInt32(1000 / (360 * Math.Abs(phasorFrequency - RefFrequency)));      //in millisecond
            }

           
            t.Tick += new EventHandler(this.t_Tick);

            t.Start();


        }

       
        private void t_Tick(object sender, EventArgs e)
        {
            //pen
            p = new Pen(Color.SaddleBrown, 5);

            //graphics
            g = Graphics.FromImage(bmp);

            

            #region[ calculate x, y coordinate of HAND]

            if (freq == true)
            {
                if (u >= 0 && u <= 180)             //main hand
                {
                    //right half
                    //u in degree is converted into radian.

                    x = cx + (int)(phasorMag * Math.Sin(Math.PI * u / 180));
                    y = cy - (int)(phasorMag * Math.Cos(Math.PI * u / 180));
                }
                else   //left half
                {
                    x = cx - (int)(phasorMag * -Math.Sin(Math.PI * u / 180));
                    y = cy - (int)(phasorMag * Math.Cos(Math.PI * u / 180));
                }


            }
            else   //when incoming phasor is slower than ref phasor
            {
                if (u >= 0 && u <= 180)
                {
                    //right half


                    x = cx + (int)(phasorMag * -Math.Sin(Math.PI * u / 180));
                    y = cy - (int)(phasorMag * Math.Cos(Math.PI * u / 180));
                }
                else
                {
                    x = cx - (int)(phasorMag * Math.Sin(Math.PI * u / 180));
                    y = cy - (int)(phasorMag * Math.Cos(Math.PI * u / 180));
                }


            }
            #endregion

            phasorvolt = RefMag + (phasorMag - 150) * Vmag_tolerance * RefMag / (3 * 10);   //I have made 3 clicks change 0.05 pu and that too due to limitation of graphics size.
            SolidBrush mybrush1 = new SolidBrush(Color.Khaki);
            Pen p2 = new Pen(Color.Black, 2);
            g.FillRectangle(new SolidBrush(Color.SeaShell), 0, 0, WIDTH + 100, HEIGHT + 100);       //Bitmap color fill
            g.FillEllipse(mybrush1, cx - WIDTH / 2, cy - HEIGHT / 2, WIDTH, HEIGHT);                //synchroscope color fill and outline
            g.DrawEllipse(p2, cx - WIDTH / 2, cy - HEIGHT / 2, WIDTH, HEIGHT);
           


            #region[ Alarm boxes]
            if (Math.Abs(RefFrequency - phasorFrequency)<=frequency_tolerance)
            {
                Freq_Alarm_Box.Text = "Within Limits :No Action Necessary";
            }
            else if (phasorFrequency >= RefFrequency)
            {
                Freq_Alarm_Box.Text = "Lower By" + (Math.Abs(RefFrequency - phasorFrequency)).ToString("c").Remove(0, 1);             
            }
            else
            {
                Freq_Alarm_Box.Text = "Raise By" + (Math.Abs(RefFrequency - phasorFrequency)).ToString("c").Remove(0, 1);
            }

            if (Math.Abs(RefMag - phasorvolt)/RefMag <= 0.02)   //I have kept 2% deviation max for alarming whereas tolerance is 5%
            {
                Vmag_Alarm_Box.Text = "Within Limits :No Action Necessary";
            }
            else if (phasorvolt >= RefMag)
            {
                Vmag_Alarm_Box.Text = "Lower By" + (Math.Abs(RefMag - phasorvolt)).ToString("c").Remove(0, 1);
            }
            else
            {
                Vmag_Alarm_Box.Text = "Raise by" + (Math.Abs(RefMag - phasorvolt)).ToString("c").Remove(0, 1);
            }
            #endregion

            #region[ Indication for Slow and Fast rotation ]
            g.DrawString("SLOW", new Font("Arial", 20), Brushes.Red, new PointF(cx - 120, HEIGHT / 3));
            //g.DrawString("SLOW", new Font("Arial", 20), Brushes.Red, new PointF(350,300));
            g.DrawString("FAST", new Font("Arial", 20), Brushes.Green, new PointF(cx + 50, HEIGHT / 3));
            #endregion

            //Angle tolerance window
            SolidBrush mybrush3 = new SolidBrush(Color.PaleGreen);
            g.FillPie(mybrush3, cx - 100, cy - WIDTH / 2, WIDTH - 100, HEIGHT, 255, 30);
            g.DrawPie(p2, cx - 100, cy - WIDTH / 2, WIDTH - 100, HEIGHT, 255, 30);    //Angle tolerance window fill and outline

            //Draw reference phasor at 12 o'clock position
            g.DrawLine(p2, new Point(cx, cy - WIDTH / 2), new Point(cx, cy));

            #region[ Draw advanced angle depending upon delay and freq diff(slip)]            
            if ((phasorFrequency - RefFrequency) >= 0)       //ideally Adv_angle should be calculated when incoming phasor freq >=Reffrequency 
                                                             //right half of plane                       //as power flow should be from incoming island to Ref island but can be calculated both ways.
            {
                Adv_angle = (delay * 60 * 360 * (phasorFrequency - RefFrequency)) / (60 * 1000);
                xnew = cx + (int)(150 * -Math.Sin(Math.PI * Adv_angle / 180));
                ynew = cy - (int)(150 * Math.Cos(Math.PI * Adv_angle / 180));
            }
            else      //left half of plane
            {
                Adv_angle = (delay * 60 * 360 * (RefFrequency - phasorFrequency)) / (60 * 1000);
                xnew = cx - (int)(150 * -Math.Sin(Math.PI * Adv_angle / 180));
                ynew = cy - (int)(150 * Math.Cos(Math.PI * Adv_angle / 180));
            }
            Pen p3 = new Pen(Color.Red, 4);
            p3.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(p3, new Point(cx, cy), new Point(xnew, ynew));

            #endregion


            #region[ To find out and depict adjusted window including delays ]

            //When Incoming Frequency> RefFrequency
            if ((phasorFrequency - RefFrequency) >= 0)
            {
                allowed_inititation_angle = 360 - phaseangle_tolerance - Adv_angle;
                if (Adv_angle >= phaseangle_tolerance)
                {

                    allowed_termination_angle = 360 + phaseangle_tolerance - Adv_angle;
                }
                else
                {

                    allowed_termination_angle = (phaseangle_tolerance - Adv_angle);
                }


            }
            //When Incoming Frequency< RefFrequency
            else
            {
                allowed_inititation_angle = phaseangle_tolerance + Adv_angle;
                if (Adv_angle >= phaseangle_tolerance)
                {

                    allowed_termination_angle = Adv_angle - phaseangle_tolerance;
                }
                else
                {

                    allowed_termination_angle = 360 - phaseangle_tolerance + Adv_angle;
                }

            }
            
            //Depict allowed breaker closing adjusted window after delay
            x_start = cx - (int)(150 * -Math.Sin(Math.PI * allowed_inititation_angle / 180));
            y_start = cy - (int)(150 * Math.Cos(Math.PI * allowed_inititation_angle / 180));
            g.DrawLine(new Pen(Color.SlateGray, 4), new Point(cx, cy), new Point(x_start, y_start));

            x_end = cx - (int)(150 * -Math.Sin(Math.PI * allowed_termination_angle / 180));
            y_end = cy - (int)(150 * Math.Cos(Math.PI * allowed_termination_angle / 180));
            g.DrawLine(new Pen(Color.SlateGray, 4), new Point(cx, cy), new Point(x_end, y_end));

            #endregion

            

            freqIncomingPhasorTextBox.Text = phasorFrequency.ToString("c").Remove(0, 1);
            freqReferencePhasorTextBox.Text = RefFrequency.ToString("c").Remove(0, 1);
                    
            //Depict Adv_angle value in respective textbox
            advanceAngleTextBox.Text = Adv_angle.ToString("c").Remove(0, 1);

            //draw rotating phasorMag
            p.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(p, new Point(cx, cy), new Point(x, y));

            //Center breaker indication initially green(open)
            SolidBrush mybrush2 = new SolidBrush(Color.Green);
            g.FillEllipse(mybrush2, cx - 30, cy - 30, WIDTH / 5, HEIGHT / 5);
            g.DrawEllipse(p2, cx - 30, cy - 30, WIDTH / 5, HEIGHT / 5);

            #region [Voltage and frequency Checklist indication]
            //indication of frequency requirements
            if (((phasorFrequency - RefFrequency) <= frequency_tolerance && phasorFrequency >= RefFrequency) || (RefFrequency - phasorFrequency <= frequency_tolerance && RefFrequency > phasorFrequency))
            {
                g.FillRectangle(new SolidBrush(Color.PaleGreen), cx - 180, HEIGHT - 20, 50, 25);
            }
            else { g.FillRectangle(new SolidBrush(Color.Salmon), cx - 180, HEIGHT - 20, 50, 25); }

            //indication of voltage requirements
            if (phasorMag >= 120 && phasorMag <= 180)
            {
                g.FillRectangle(new SolidBrush(Color.PaleGreen), cx + 130, HEIGHT - 20, 50, 25);
            }
            else { g.FillRectangle(new SolidBrush(Color.Salmon), cx + 130, HEIGHT - 20, 50, 25); }
            

            g.DrawString("Freq", new Font("Arial", 12), Brushes.Black, new PointF(cx - 180, HEIGHT - 20));
            g.DrawString("Vmag", new Font("Arial", 12), Brushes.Black, new PointF(cx + 130, HEIGHT - 20));
            #endregion

            //load bitmap in picturebox1
            pictureBox1.Image = bmp;

            //Auto Manual mode 
            if (auto == true)
            {
                manualModeButton.BackColor = default(Color);
                autoModeButton.BackColor = Color.Red;
                allowed_inititation_angle += phaseangle_tolerance;
                breakerCloseButton.PerformClick();
            }
            else
            {
                autoModeButton.BackColor = default(Color);
                manualModeButton.BackColor = Color.Red;
            }

            //calculate final breaker closing angle (after final closing)
            if ((u_initiated + Adv_angle) >= 360)
            {
                u_adjusted = u_initiated + Adv_angle - 360;
            }
            else
            {
                u_adjusted = u_initiated + Adv_angle;
            }
                    

            //Indication of breaker after u_adjusted is reached
            //in actual
            if (breaker == true)
            {
                if ((int)(u - u_adjusted) == 0)
                {
                    t.Stop();
                    g.FillEllipse(new SolidBrush(Color.Red), cx - 30, cy - 30, WIDTH / 5, HEIGHT / 5);
                    g.DrawEllipse(new Pen(Color.Black, 1f), cx - 30, cy - 30, WIDTH / 5, HEIGHT / 5);
                    pictureBox1.Image = bmp;
                    breaker = false;
                }
            }

            //update in later stages of Beta version
            //u = Algorithm.inputData.test_VoltAng2 - Algorithm.inputData.test_VoltAng1;

            //if clockwise direction + or else - from the below
            //u = (Algorithm.inputData.test_VoltAng2 - Algorithm.inputData.test_VoltAng1)+(some_count/(360*(Math.Abs(RefFrequency-phasorFrequency))));
            //and increment count till the next time update synchrousform is not called and then revert back some_count =0.

            //But now we are incrementing it each step to show the functionality
            u++;

            if (u == 360)
            {
                u = 0;

            }
            //count++;    //deliberately incrementing to emulate rotating phasor as phase difference will keep increasing between both phasors
            
            //dispose
            p.Dispose();
            g.Dispose();
            
        }
        public void updateSynchronousForm()
        {
            
            //Textbox Values representation
            voltageIncomingPhasorTextBox.Text = Convert.ToString(Algorithm.inputData.test_VoltMag1 / 1000);
            voltageReferencePhasorTextBox.Text = Convert.ToString(Algorithm.inputData.test_VoltMag2 / 1000);
            IncomingVangTextbox.Text = Convert.ToString(Algorithm.inputData.test_VoltAng2);
            RefAngtextbox.Text = Convert.ToString(Algorithm.inputData.test_VoltAng1);    
            TimeIntervalupdate();
        }
        public void TimeIntervalupdate()
        {
            if (Math.Abs(RefFrequency - phasorFrequency) < 0.005)
            {
                t.Interval = 10000000;      //if slip is very minimal(<0.005 Hz) we assign a significantly large value to make the phasormag hand stop
                                            //because following the formula gives t.Interval is nearly equal to infinity . 
            }
            else
            {
                if (t.Interval <= 1)
                {
                    t.Interval = t.Interval - 0;
                }
                else
                {
                    t.Interval = Convert.ToInt32(1000 / (360 * Math.Abs(RefFrequency - phasorFrequency)));   //in milliseconds
                }

            }
            #region[Change Directions if necessary]
            if (freq == true)           //freq boolean variable represents direction of rotation...if true then clockwise and vice versa
            {                
                
                //change direction of rotation if necessary
                if (phasorFrequency < RefFrequency)     

                {
                    freq = !freq;       //change direction of rotation
                    u = 360 - u;

                }
            }
            else
            {
                if (phasorFrequency > RefFrequency)     //change direction of rotation  if necessary                               
                {
                    freq = !freq;
                    u = 360 - u;
                }
            }
            #endregion
        }
    }
}