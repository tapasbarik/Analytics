// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using ECAClientFramework;
using ECAClientUtilities;
using ECACommonUtilities;
using ECACommonUtilities.Model;
using GSF.TimeSeries;

namespace VoltageInput_Synch.Model
{
    [CompilerGenerated]
    public class Mapper : MapperBase
    {
        #region [ Constructors ]

        public Mapper(Framework framework)
            : base(framework, "test_DataIn")
        {
        }

        #endregion

        #region [ Methods ]

        public override void Map(IDictionary<MeasurementKey, IMeasurement> measurements)
        {
            SignalLookup.UpdateMeasurementLookup(measurements);
            TypeMapping inputMapping = MappingCompiler.GetTypeMapping(InputMapping);

            VoltageInput_Synch.Model.GPA.test_DataIn inputData = CreateGPAtest_DataIn(inputMapping);
            KeyIndex = 0;
            VoltageInput_Synch.Model.GPA._test_DataInMeta inputMeta = CreateGPA_test_DataInMeta(inputMapping);

            Algorithm.Output algorithmOutput = Algorithm.Execute(inputData, inputMeta);

            // TODO: Later versions will publish output to the openECA server
        }

        private VoltageInput_Synch.Model.GPA.test_DataIn CreateGPAtest_DataIn(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            VoltageInput_Synch.Model.GPA.test_DataIn obj = new VoltageInput_Synch.Model.GPA.test_DataIn();

            {
                // Assign double value to "test_VoltMag1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag1 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltAng1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng1 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltMag2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag2 = (double)measurement.Value;
            }

            {
                // Assign double value to "test_VoltAng2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng2 = (double)measurement.Value;
            }

            return obj;
        }

        private VoltageInput_Synch.Model.GPA._test_DataInMeta CreateGPA_test_DataInMeta(TypeMapping typeMapping)
        {
            Dictionary<string, FieldMapping> fieldLookup = typeMapping.FieldMappings.ToDictionary(mapping => mapping.Field.Identifier);
            VoltageInput_Synch.Model.GPA._test_DataInMeta obj = new VoltageInput_Synch.Model.GPA._test_DataInMeta();

            {
                // Assign MetaValues value to "test_VoltMag1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag1 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltAng1" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng1"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng1 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltMag2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltMag2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltMag2 = GetMetaValues(measurement);
            }

            {
                // Assign MetaValues value to "test_VoltAng2" field
                FieldMapping fieldMapping = fieldLookup["test_VoltAng2"];
                IMeasurement measurement = GetMeasurement(fieldMapping);
                obj.test_VoltAng2 = GetMetaValues(measurement);
            }

            return obj;
        }

        #endregion
    }
}
