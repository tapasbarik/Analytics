// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;
using ECAClientFramework;

namespace VoltageInput_Synch.Model.GPA
{
    [CompilerGenerated]
    public partial class _test_DataOutMeta
    {
        public MetaValues test_output { get; set; }
    }
}