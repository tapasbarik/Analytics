// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;
using ECAClientFramework;

namespace VoltageInput_Synch.Model.GPA
{
    [CompilerGenerated]
    public partial class _test_DataInMeta
    {
        public MetaValues test_VoltMag1 { get; set; }
        public MetaValues test_VoltAng1 { get; set; }
        public MetaValues test_VoltMag2 { get; set; }
        public MetaValues test_VoltAng2 { get; set; }
    }
}