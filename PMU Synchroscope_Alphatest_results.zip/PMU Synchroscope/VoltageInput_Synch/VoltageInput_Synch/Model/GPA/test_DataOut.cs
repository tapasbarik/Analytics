// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System.Runtime.CompilerServices;

namespace VoltageInput_Synch.Model.GPA
{
    [CompilerGenerated]
    public partial class test_DataOut
    {
        public double test_output { get; set; }
    }
}