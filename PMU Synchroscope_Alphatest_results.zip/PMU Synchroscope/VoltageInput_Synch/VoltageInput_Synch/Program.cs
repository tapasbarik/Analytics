// COMPILER GENERATED CODE
// THIS WILL BE OVERWRITTEN AT EACH GENERATION
// EDIT AT YOUR OWN RISK

using System;
using System.Windows.Forms;
using ECAClientFramework;
using VoltageInput_Synch.Model;
using System.Threading;
    

namespace VoltageInput_Synch
{
    static class Program
    {
        /// <summary>
        /// Main entry point for test_demo.
        /// </summary>
        public static synchroscopeForm syncForm;

        [STAThread]
        static void Main()
        {
            Framework framework = new Framework(fw => new Mapper(fw));


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            Algorithm.UpdateSystemSettings();

            var thread = new Thread(ThreadStart);
            // allow UI with ApartmentState.STA though [STAThread] above should give that to you
            thread.TrySetApartmentState(ApartmentState.STA);
            thread.Start();


            MainWindow mainWindow = new MainWindow(framework);
            //mainWindow.Text = "C# test_demo Test Harness";
            Application.Run(mainWindow);

        }
        private static void ThreadStart()
        {
            Program.syncForm = new synchroscopeForm();
            Application.Run(Program.syncForm); // <-- other form started on its own UI thread
        }
    }
}