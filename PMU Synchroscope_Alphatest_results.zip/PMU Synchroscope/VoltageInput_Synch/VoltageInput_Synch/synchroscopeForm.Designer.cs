﻿namespace VoltageInput_Synch
{
    partial class synchroscopeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.voltageMagLabel = new System.Windows.Forms.Label();
            this.voltageMagRaiseButton = new System.Windows.Forms.Button();
            this.voltageMagLowerButton = new System.Windows.Forms.Button();
            this.freqLowerButton = new System.Windows.Forms.Button();
            this.freqRaiseButton = new System.Windows.Forms.Button();
            this.voltagePhasorLabel = new System.Windows.Forms.Label();
            this.voltageReferencePhasorLabel = new System.Windows.Forms.Label();
            this.voltageIncomingPhasorLabel = new System.Windows.Forms.Label();
            this.freqPhasorLabel = new System.Windows.Forms.Label();
            this.freqIncomingPhasorLabel = new System.Windows.Forms.Label();
            this.freqReferencePhasorLabel = new System.Windows.Forms.Label();
            this.pmuSynchroscopeTextBox = new System.Windows.Forms.TextBox();
            this.autoModeButton = new System.Windows.Forms.Button();
            this.manualModeButton = new System.Windows.Forms.Button();
            this.breakerCloseButton = new System.Windows.Forms.Button();
            this.breakerOpenButton = new System.Windows.Forms.Button();
            this.breakerCommandLabel = new System.Windows.Forms.Label();
            this.modeLabel = new System.Windows.Forms.Label();
            this.freqLabel = new System.Windows.Forms.Label();
            this.voltageIncomingPhasorTextBox = new System.Windows.Forms.TextBox();
            this.voltageReferencePhasorTextBox = new System.Windows.Forms.TextBox();
            this.freqIncomingPhasorTextBox = new System.Windows.Forms.TextBox();
            this.freqReferencePhasorTextBox = new System.Windows.Forms.TextBox();
            this.advanceAngleLabel = new System.Windows.Forms.Label();
            this.advanceAngleTextBox = new System.Windows.Forms.TextBox();
            this.Voltage_Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Vmag_Alarm_Box = new System.Windows.Forms.TextBox();
            this.Freq_Alarm_Box = new System.Windows.Forms.TextBox();
            this.VoltageAngle = new System.Windows.Forms.Label();
            this.IncomingAngLabel = new System.Windows.Forms.Label();
            this.RefAngleLabel = new System.Windows.Forms.Label();
            this.IncomingVangTextbox = new System.Windows.Forms.TextBox();
            this.RefAngtextbox = new System.Windows.Forms.TextBox();
            this.Frequency_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Voltage_Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Frequency_chart)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(508, 476);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(608, 420);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // voltageMagLabel
            // 
            this.voltageMagLabel.AutoSize = true;
            this.voltageMagLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voltageMagLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voltageMagLabel.Location = new System.Drawing.Point(172, 672);
            this.voltageMagLabel.Name = "voltageMagLabel";
            this.voltageMagLabel.Size = new System.Drawing.Size(117, 24);
            this.voltageMagLabel.TabIndex = 1;
            this.voltageMagLabel.Text = "VoltageMag";
            this.voltageMagLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // voltageMagRaiseButton
            // 
            this.voltageMagRaiseButton.Location = new System.Drawing.Point(76, 722);
            this.voltageMagRaiseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.voltageMagRaiseButton.Name = "voltageMagRaiseButton";
            this.voltageMagRaiseButton.Size = new System.Drawing.Size(92, 35);
            this.voltageMagRaiseButton.TabIndex = 2;
            this.voltageMagRaiseButton.Text = "Raise";
            this.voltageMagRaiseButton.UseVisualStyleBackColor = true;
            this.voltageMagRaiseButton.Click += new System.EventHandler(this.voltMagRaiseButton_Click);
            // 
            // voltageMagLowerButton
            // 
            this.voltageMagLowerButton.Location = new System.Drawing.Point(252, 722);
            this.voltageMagLowerButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.voltageMagLowerButton.Name = "voltageMagLowerButton";
            this.voltageMagLowerButton.Size = new System.Drawing.Size(92, 35);
            this.voltageMagLowerButton.TabIndex = 3;
            this.voltageMagLowerButton.Text = "Lower";
            this.voltageMagLowerButton.UseVisualStyleBackColor = true;
            this.voltageMagLowerButton.Click += new System.EventHandler(this.voltageMagLowerButton_Click);
            // 
            // freqLowerButton
            // 
            this.freqLowerButton.Location = new System.Drawing.Point(1371, 727);
            this.freqLowerButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.freqLowerButton.Name = "freqLowerButton";
            this.freqLowerButton.Size = new System.Drawing.Size(92, 35);
            this.freqLowerButton.TabIndex = 5;
            this.freqLowerButton.Text = "Lower";
            this.freqLowerButton.UseVisualStyleBackColor = true;
            this.freqLowerButton.Click += new System.EventHandler(this.freqLowerButton_Click);
            // 
            // freqRaiseButton
            // 
            this.freqRaiseButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.freqRaiseButton.Location = new System.Drawing.Point(1195, 727);
            this.freqRaiseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.freqRaiseButton.Name = "freqRaiseButton";
            this.freqRaiseButton.Size = new System.Drawing.Size(92, 35);
            this.freqRaiseButton.TabIndex = 6;
            this.freqRaiseButton.Text = "Raise";
            this.freqRaiseButton.UseVisualStyleBackColor = false;
            this.freqRaiseButton.Click += new System.EventHandler(this.freqRaiseButton_Click);
            // 
            // voltagePhasorLabel
            // 
            this.voltagePhasorLabel.AutoSize = true;
            this.voltagePhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voltagePhasorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.voltagePhasorLabel.Location = new System.Drawing.Point(110, 234);
            this.voltagePhasorLabel.Name = "voltagePhasorLabel";
            this.voltagePhasorLabel.Size = new System.Drawing.Size(179, 24);
            this.voltagePhasorLabel.TabIndex = 9;
            this.voltagePhasorLabel.Text = "VoltageMag(in KV)";
            this.voltagePhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // voltageReferencePhasorLabel
            // 
            this.voltageReferencePhasorLabel.AutoSize = true;
            this.voltageReferencePhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voltageReferencePhasorLabel.Location = new System.Drawing.Point(223, 268);
            this.voltageReferencePhasorLabel.Name = "voltageReferencePhasorLabel";
            this.voltageReferencePhasorLabel.Size = new System.Drawing.Size(140, 22);
            this.voltageReferencePhasorLabel.TabIndex = 10;
            this.voltageReferencePhasorLabel.Text = "Reference Phasor";
            this.voltageReferencePhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // voltageIncomingPhasorLabel
            // 
            this.voltageIncomingPhasorLabel.AutoSize = true;
            this.voltageIncomingPhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voltageIncomingPhasorLabel.Location = new System.Drawing.Point(12, 268);
            this.voltageIncomingPhasorLabel.Name = "voltageIncomingPhasorLabel";
            this.voltageIncomingPhasorLabel.Size = new System.Drawing.Size(130, 22);
            this.voltageIncomingPhasorLabel.TabIndex = 11;
            this.voltageIncomingPhasorLabel.Text = "Incoming Phasor";
            this.voltageIncomingPhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // freqPhasorLabel
            // 
            this.freqPhasorLabel.AutoSize = true;
            this.freqPhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.freqPhasorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.freqPhasorLabel.Location = new System.Drawing.Point(1224, 234);
            this.freqPhasorLabel.Name = "freqPhasorLabel";
            this.freqPhasorLabel.Size = new System.Drawing.Size(165, 24);
            this.freqPhasorLabel.TabIndex = 12;
            this.freqPhasorLabel.Text = "Frequency(in Hz)";
            this.freqPhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // freqIncomingPhasorLabel
            // 
            this.freqIncomingPhasorLabel.AutoSize = true;
            this.freqIncomingPhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.freqIncomingPhasorLabel.Location = new System.Drawing.Point(1142, 268);
            this.freqIncomingPhasorLabel.Name = "freqIncomingPhasorLabel";
            this.freqIncomingPhasorLabel.Size = new System.Drawing.Size(130, 22);
            this.freqIncomingPhasorLabel.TabIndex = 13;
            this.freqIncomingPhasorLabel.Text = "Incoming Phasor";
            this.freqIncomingPhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // freqReferencePhasorLabel
            // 
            this.freqReferencePhasorLabel.AutoSize = true;
            this.freqReferencePhasorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.freqReferencePhasorLabel.Location = new System.Drawing.Point(1313, 268);
            this.freqReferencePhasorLabel.Name = "freqReferencePhasorLabel";
            this.freqReferencePhasorLabel.Size = new System.Drawing.Size(140, 22);
            this.freqReferencePhasorLabel.TabIndex = 14;
            this.freqReferencePhasorLabel.Text = "Reference Phasor";
            this.freqReferencePhasorLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pmuSynchroscopeTextBox
            // 
            this.pmuSynchroscopeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pmuSynchroscopeTextBox.Location = new System.Drawing.Point(647, 439);
            this.pmuSynchroscopeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pmuSynchroscopeTextBox.Name = "pmuSynchroscopeTextBox";
            this.pmuSynchroscopeTextBox.Size = new System.Drawing.Size(326, 30);
            this.pmuSynchroscopeTextBox.TabIndex = 16;
            this.pmuSynchroscopeTextBox.Text = "PMU SYNCHROSCOPE";
            this.pmuSynchroscopeTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // autoModeButton
            // 
            this.autoModeButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.autoModeButton.Location = new System.Drawing.Point(680, 69);
            this.autoModeButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.autoModeButton.Name = "autoModeButton";
            this.autoModeButton.Size = new System.Drawing.Size(92, 35);
            this.autoModeButton.TabIndex = 17;
            this.autoModeButton.Text = "Auto";
            this.autoModeButton.UseVisualStyleBackColor = false;
            this.autoModeButton.Click += new System.EventHandler(this.autoModeButton_Click);
            // 
            // manualModeButton
            // 
            this.manualModeButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.manualModeButton.Location = new System.Drawing.Point(856, 69);
            this.manualModeButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.manualModeButton.Name = "manualModeButton";
            this.manualModeButton.Size = new System.Drawing.Size(92, 35);
            this.manualModeButton.TabIndex = 18;
            this.manualModeButton.Text = "Manual";
            this.manualModeButton.UseVisualStyleBackColor = false;
            this.manualModeButton.Click += new System.EventHandler(this.manualModeButton_Click);
            // 
            // breakerCloseButton
            // 
            this.breakerCloseButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.breakerCloseButton.Location = new System.Drawing.Point(877, 968);
            this.breakerCloseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.breakerCloseButton.Name = "breakerCloseButton";
            this.breakerCloseButton.Size = new System.Drawing.Size(92, 35);
            this.breakerCloseButton.TabIndex = 19;
            this.breakerCloseButton.Text = "Close";
            this.breakerCloseButton.UseVisualStyleBackColor = false;
            this.breakerCloseButton.Click += new System.EventHandler(this.breakerCloseButton_Click);
            // 
            // breakerOpenButton
            // 
            this.breakerOpenButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.breakerOpenButton.Location = new System.Drawing.Point(665, 968);
            this.breakerOpenButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.breakerOpenButton.Name = "breakerOpenButton";
            this.breakerOpenButton.Size = new System.Drawing.Size(92, 35);
            this.breakerOpenButton.TabIndex = 20;
            this.breakerOpenButton.Text = "Open";
            this.breakerOpenButton.UseVisualStyleBackColor = false;
            this.breakerOpenButton.Click += new System.EventHandler(this.breakerOpenButton_Click);
            // 
            // breakerCommandLabel
            // 
            this.breakerCommandLabel.AutoSize = true;
            this.breakerCommandLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.breakerCommandLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakerCommandLabel.Location = new System.Drawing.Point(718, 925);
            this.breakerCommandLabel.Name = "breakerCommandLabel";
            this.breakerCommandLabel.Size = new System.Drawing.Size(193, 27);
            this.breakerCommandLabel.TabIndex = 21;
            this.breakerCommandLabel.Text = "Breaker Command";
            this.breakerCommandLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // modeLabel
            // 
            this.modeLabel.AutoSize = true;
            this.modeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.modeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modeLabel.Location = new System.Drawing.Point(784, 25);
            this.modeLabel.Name = "modeLabel";
            this.modeLabel.Size = new System.Drawing.Size(69, 24);
            this.modeLabel.TabIndex = 22;
            this.modeLabel.Text = "MODE";
            this.modeLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // freqLabel
            // 
            this.freqLabel.AutoSize = true;
            this.freqLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.freqLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.freqLabel.Location = new System.Drawing.Point(1283, 687);
            this.freqLabel.Name = "freqLabel";
            this.freqLabel.Size = new System.Drawing.Size(106, 24);
            this.freqLabel.TabIndex = 4;
            this.freqLabel.Text = "Frequency";
            this.freqLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // voltageIncomingPhasorTextBox
            // 
            this.voltageIncomingPhasorTextBox.Location = new System.Drawing.Point(12, 314);
            this.voltageIncomingPhasorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.voltageIncomingPhasorTextBox.Name = "voltageIncomingPhasorTextBox";
            this.voltageIncomingPhasorTextBox.Size = new System.Drawing.Size(114, 26);
            this.voltageIncomingPhasorTextBox.TabIndex = 23;
            this.voltageIncomingPhasorTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // voltageReferencePhasorTextBox
            // 
            this.voltageReferencePhasorTextBox.Location = new System.Drawing.Point(234, 314);
            this.voltageReferencePhasorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.voltageReferencePhasorTextBox.Name = "voltageReferencePhasorTextBox";
            this.voltageReferencePhasorTextBox.Size = new System.Drawing.Size(116, 26);
            this.voltageReferencePhasorTextBox.TabIndex = 24;
            this.voltageReferencePhasorTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // freqIncomingPhasorTextBox
            // 
            this.freqIncomingPhasorTextBox.Location = new System.Drawing.Point(1142, 308);
            this.freqIncomingPhasorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.freqIncomingPhasorTextBox.Name = "freqIncomingPhasorTextBox";
            this.freqIncomingPhasorTextBox.Size = new System.Drawing.Size(116, 26);
            this.freqIncomingPhasorTextBox.TabIndex = 25;
            this.freqIncomingPhasorTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // freqReferencePhasorTextBox
            // 
            this.freqReferencePhasorTextBox.Location = new System.Drawing.Point(1328, 308);
            this.freqReferencePhasorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.freqReferencePhasorTextBox.Name = "freqReferencePhasorTextBox";
            this.freqReferencePhasorTextBox.Size = new System.Drawing.Size(116, 26);
            this.freqReferencePhasorTextBox.TabIndex = 26;
            this.freqReferencePhasorTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // advanceAngleLabel
            // 
            this.advanceAngleLabel.AutoSize = true;
            this.advanceAngleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.advanceAngleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.advanceAngleLabel.Location = new System.Drawing.Point(130, 914);
            this.advanceAngleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advanceAngleLabel.Name = "advanceAngleLabel";
            this.advanceAngleLabel.Size = new System.Drawing.Size(159, 27);
            this.advanceAngleLabel.TabIndex = 27;
            this.advanceAngleLabel.Text = "Advanced Angle";
            // 
            // advanceAngleTextBox
            // 
            this.advanceAngleTextBox.Location = new System.Drawing.Point(130, 968);
            this.advanceAngleTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.advanceAngleTextBox.Name = "advanceAngleTextBox";
            this.advanceAngleTextBox.Size = new System.Drawing.Size(163, 26);
            this.advanceAngleTextBox.TabIndex = 28;
            this.advanceAngleTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Voltage_Chart
            // 
            chartArea3.Name = "ChartArea1";
            this.Voltage_Chart.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.Voltage_Chart.Legends.Add(legend3);
            this.Voltage_Chart.Location = new System.Drawing.Point(21, 396);
            this.Voltage_Chart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Voltage_Chart.Name = "Voltage_Chart";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Legend1";
            series3.Name = "Voltage_mag_graph";
            this.Voltage_Chart.Series.Add(series3);
            this.Voltage_Chart.Size = new System.Drawing.Size(403, 202);
            this.Voltage_Chart.TabIndex = 29;
            this.Voltage_Chart.Text = "chart1";
            this.Voltage_Chart.Click += new System.EventHandler(this.Voltage_Chart_Click);
            // 
            // Vmag_Alarm_Box
            // 
            this.Vmag_Alarm_Box.Location = new System.Drawing.Point(90, 791);
            this.Vmag_Alarm_Box.Multiline = true;
            this.Vmag_Alarm_Box.Name = "Vmag_Alarm_Box";
            this.Vmag_Alarm_Box.Size = new System.Drawing.Size(251, 59);
            this.Vmag_Alarm_Box.TabIndex = 34;
            this.Vmag_Alarm_Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Vmag_Alarm_Box.TextChanged += new System.EventHandler(this.Vmag_Alarm_Box_TextChanged);
            // 
            // Freq_Alarm_Box
            // 
            this.Freq_Alarm_Box.Location = new System.Drawing.Point(1232, 806);
            this.Freq_Alarm_Box.Multiline = true;
            this.Freq_Alarm_Box.Name = "Freq_Alarm_Box";
            this.Freq_Alarm_Box.Size = new System.Drawing.Size(211, 59);
            this.Freq_Alarm_Box.TabIndex = 35;
            this.Freq_Alarm_Box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VoltageAngle
            // 
            this.VoltageAngle.AutoSize = true;
            this.VoltageAngle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.VoltageAngle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VoltageAngle.Location = new System.Drawing.Point(709, 234);
            this.VoltageAngle.Name = "VoltageAngle";
            this.VoltageAngle.Size = new System.Drawing.Size(187, 24);
            this.VoltageAngle.TabIndex = 36;
            this.VoltageAngle.Text = "VoltageAng(in Deg)";
            this.VoltageAngle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.VoltageAngle.Click += new System.EventHandler(this.label1_Click);
            // 
            // IncomingAngLabel
            // 
            this.IncomingAngLabel.AutoSize = true;
            this.IncomingAngLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IncomingAngLabel.Location = new System.Drawing.Point(618, 268);
            this.IncomingAngLabel.Name = "IncomingAngLabel";
            this.IncomingAngLabel.Size = new System.Drawing.Size(130, 22);
            this.IncomingAngLabel.TabIndex = 37;
            this.IncomingAngLabel.Text = "Incoming Phasor";
            // 
            // RefAngleLabel
            // 
            this.RefAngleLabel.AutoSize = true;
            this.RefAngleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RefAngleLabel.Location = new System.Drawing.Point(856, 268);
            this.RefAngleLabel.Name = "RefAngleLabel";
            this.RefAngleLabel.Size = new System.Drawing.Size(140, 22);
            this.RefAngleLabel.TabIndex = 38;
            this.RefAngleLabel.Text = "Reference Phasor";
            // 
            // IncomingVangTextbox
            // 
            this.IncomingVangTextbox.Location = new System.Drawing.Point(630, 314);
            this.IncomingVangTextbox.Name = "IncomingVangTextbox";
            this.IncomingVangTextbox.Size = new System.Drawing.Size(118, 26);
            this.IncomingVangTextbox.TabIndex = 39;
            this.IncomingVangTextbox.TextChanged += new System.EventHandler(this.IncomingVangTextbox_TextChanged);
            // 
            // RefAngtextbox
            // 
            this.RefAngtextbox.Location = new System.Drawing.Point(867, 314);
            this.RefAngtextbox.Name = "RefAngtextbox";
            this.RefAngtextbox.Size = new System.Drawing.Size(119, 26);
            this.RefAngtextbox.TabIndex = 40;
            this.RefAngtextbox.TextChanged += new System.EventHandler(this.RefAngtextbox_TextChanged);
            // 
            // Frequency_chart
            // 
            chartArea4.Name = "ChartArea1";
            this.Frequency_chart.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.Frequency_chart.Legends.Add(legend4);
            this.Frequency_chart.Location = new System.Drawing.Point(1168, 396);
            this.Frequency_chart.Name = "Frequency_chart";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series4.Legend = "Legend1";
            series4.Name = "Frequency";
            this.Frequency_chart.Series.Add(series4);
            this.Frequency_chart.Size = new System.Drawing.Size(416, 247);
            this.Frequency_chart.TabIndex = 41;
            this.Frequency_chart.Text = "chart1";
            // 
            // synchroscopeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1651, 1028);
            this.Controls.Add(this.Frequency_chart);
            this.Controls.Add(this.RefAngtextbox);
            this.Controls.Add(this.IncomingVangTextbox);
            this.Controls.Add(this.RefAngleLabel);
            this.Controls.Add(this.IncomingAngLabel);
            this.Controls.Add(this.VoltageAngle);
            this.Controls.Add(this.Freq_Alarm_Box);
            this.Controls.Add(this.Vmag_Alarm_Box);
            this.Controls.Add(this.Voltage_Chart);
            this.Controls.Add(this.advanceAngleTextBox);
            this.Controls.Add(this.advanceAngleLabel);
            this.Controls.Add(this.freqReferencePhasorTextBox);
            this.Controls.Add(this.freqIncomingPhasorTextBox);
            this.Controls.Add(this.voltageReferencePhasorTextBox);
            this.Controls.Add(this.voltageIncomingPhasorTextBox);
            this.Controls.Add(this.modeLabel);
            this.Controls.Add(this.breakerCommandLabel);
            this.Controls.Add(this.breakerOpenButton);
            this.Controls.Add(this.breakerCloseButton);
            this.Controls.Add(this.manualModeButton);
            this.Controls.Add(this.autoModeButton);
            this.Controls.Add(this.pmuSynchroscopeTextBox);
            this.Controls.Add(this.freqReferencePhasorLabel);
            this.Controls.Add(this.freqIncomingPhasorLabel);
            this.Controls.Add(this.freqPhasorLabel);
            this.Controls.Add(this.voltageIncomingPhasorLabel);
            this.Controls.Add(this.voltageReferencePhasorLabel);
            this.Controls.Add(this.voltagePhasorLabel);
            this.Controls.Add(this.freqRaiseButton);
            this.Controls.Add(this.freqLowerButton);
            this.Controls.Add(this.freqLabel);
            this.Controls.Add(this.voltageMagLowerButton);
            this.Controls.Add(this.voltageMagRaiseButton);
            this.Controls.Add(this.voltageMagLabel);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "synchroscopeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VSynchroscope";
            this.Load += new System.EventHandler(this.synchroscopeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Voltage_Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Frequency_chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label voltageMagLabel;
        private System.Windows.Forms.Button voltageMagRaiseButton;
        private System.Windows.Forms.Button voltageMagLowerButton;
        private System.Windows.Forms.Button freqLowerButton;
        private System.Windows.Forms.Button freqRaiseButton;
        private System.Windows.Forms.Label voltagePhasorLabel;
        private System.Windows.Forms.Label voltageReferencePhasorLabel;
        private System.Windows.Forms.Label voltageIncomingPhasorLabel;
        private System.Windows.Forms.Label freqPhasorLabel;
        private System.Windows.Forms.Label freqIncomingPhasorLabel;
        private System.Windows.Forms.Label freqReferencePhasorLabel;
        private System.Windows.Forms.TextBox pmuSynchroscopeTextBox;
        private System.Windows.Forms.Button autoModeButton;
        private System.Windows.Forms.Button manualModeButton;
        private System.Windows.Forms.Button breakerCloseButton;
        private System.Windows.Forms.Button breakerOpenButton;
        private System.Windows.Forms.Label breakerCommandLabel;
        private System.Windows.Forms.Label modeLabel;
        private System.Windows.Forms.Label freqLabel;
        private System.Windows.Forms.TextBox voltageIncomingPhasorTextBox;
        private System.Windows.Forms.TextBox voltageReferencePhasorTextBox;
        private System.Windows.Forms.TextBox freqIncomingPhasorTextBox;
        private System.Windows.Forms.TextBox freqReferencePhasorTextBox;
        private System.Windows.Forms.Label advanceAngleLabel;
        private System.Windows.Forms.TextBox advanceAngleTextBox;
        private System.Windows.Forms.DataVisualization.Charting.Chart Voltage_Chart;
        //private System.Windows.Forms.Label voltageIncomingPhasorValLabel;
        //private System.Windows.Forms.Label freqIncomingPhasorValLabel;
        //private System.Windows.Forms.Label freqIncomingPhasorAngleLabel;
        //private System.Windows.Forms.Label voltageIncomingPhasorAngleLabel;
        private System.Windows.Forms.TextBox Vmag_Alarm_Box;
        private System.Windows.Forms.TextBox Freq_Alarm_Box;
        private System.Windows.Forms.Label VoltageAngle;
        private System.Windows.Forms.Label IncomingAngLabel;
        private System.Windows.Forms.Label RefAngleLabel;
        private System.Windows.Forms.TextBox IncomingVangTextbox;
        private System.Windows.Forms.TextBox RefAngtextbox;
        private System.Windows.Forms.DataVisualization.Charting.Chart Frequency_chart;
    }
}

