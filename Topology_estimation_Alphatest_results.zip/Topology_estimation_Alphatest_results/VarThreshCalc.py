import os,sys
installPath = os.path.dirname(os.getcwd())
Library = os.path.dirname(installPath) + '\\Library'
#------------------------------------------------------------------------------#
# NEEDED PATH APPENDICES					               #
#------------------------------------------------------------------------------#
sys.path.append(Library)
pssebindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSBIN"
os.environ['PATH'] = pssebindir + ';' + os.environ['PATH']
sys.path.insert(0,pssebindir)
psspybindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSPY27"
sys.path.insert(0,psspybindir)
#------------------------------------------------------------------------------#
# MODULES       						               #
#------------------------------------------------------------------------------#
import operator, pdb
import psspy
import csv, itertools


Sav = 'ieee118bus_substations_eachloadminus10.sav'
#Sav = 'IEEE 14 bus Substations.sav'
#Sav = 'test.sav'

#------------------------------------------------------------------------------#
# USER PATHS								       #
#------------------------------------------------------------------------------#
PathSav = installPath + '\\TopEst'	    # Path for .sav

#------------------------------------------------------------------------------#
# MAIN PROGRAM      						               #
#------------------------------------------------------------------------------#
import redirect
redirect.psse2py()
psspy.psseinit(2000000)
psspy.case(PathSav+'\\'+Sav)
sid = 1
#######################################################################################################################
#----------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------

def main():

    #defines the maximum number of connections to process in a substation(for computational reasons)
    max_size=15
    batch_size=200

    temp = psspy.abrnint(-1, 1, 1, 1, 1, ['fromnumber', 'tonumber'])
    all_from_buses = temp[1][0]
    all_to_buses = temp[1][1]
    temp2 = psspy.abrnchar(-1, 1, 1, 1, 1, ['fromname', 'toname', 'id'])
    all_from_names = temp2[1][0]
    all_to_names = temp2[1][1]
    all_id = temp2[1][2]

    _i=psspy.getdefaultint()
    _f=psspy.getdefaultreal()
    _s=psspy.getdefaultchar()

    #reads configuration file
    csv_in=open("ConfigFile_118.csv", 'rb')
    myreader=csv.reader(csv_in, lineterminator='\n')
    input_configs=[]
    for row in myreader:
        input_configs.append(row)
    num_subs=len(input_configs)

    bus_matrix = psspy.abusint(-1, 1, ['NUMBER', 'type', 'area', 'zone', 'owner'])      #call the Bus info for the first time
    bus_nums = bus_matrix[1][0]

    num_batches=num_subs//batch_size
    remain=num_subs%batch_size

    #loop through each substation
    for batch in range(num_batches):
        disc_ang = []
        conn_ang = []
        disc_mag = []
        conn_mag = []
        disc_names = []
        conn_names = []
        disc_configs = []
        conn_configs = []
        for i in range(batch_size*(batch+1)-batch_size,batch_size*(batch+1)):
            num_connecs=int(input_configs[i][0])
            if num_connecs>max_size:
                num_connecs=max_size

            #creates truthtable of size corresponding to the number of connections
            table = list(itertools.product([1, 0], repeat=num_connecs))

            #checks each configuration in the truthtable and updates network to match new case
            for j in range(len(table)):

                # reopen psse file to default case
                redirect.psse2py()
                psspy.psseinit(2000000)
                psspy.case(PathSav + '\\' + Sav)
                sid = 1

                curr_config=table[j]
                for k in range(num_connecs):
                    if curr_config[k]==0:
                        #psspy.branch_data(int(input_configs[i][(3*k)+1]), int(input_configs[i][(3*k)+2]),input_configs[i][(3*k)+3] , [0])
                        psspy.system_swd_chng(int(input_configs[i][(3*k)+1]), int(input_configs[i][(3*k)+2]),input_configs[i][(3*k)+3] , [0,_i,_i,_i],_f,[_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f],_s)
                        #pdb.set_trace()
                psspy.fnsl()

                bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angled'])
                bus_bases = bus_volt_matrix[1][0]
                V = bus_volt_matrix[1][1]
                Delta = bus_volt_matrix[1][2]  # in degrees

                sol=psspy.solved()
                if sol==0:
                    for k in range(num_connecs):
                        if curr_config[k]==0:
                            disc_names.append([int(input_configs[i][(3 * k) + 1])])
                            disc_names[-1].append(all_from_names[all_from_buses.index(int(input_configs[i][(3*k)+1]))])
                            disc_names[-1].append(int(input_configs[i][(3 * k) + 2]))
                            disc_names[-1].append(all_to_names[all_to_buses.index(int(input_configs[i][(3 * k) + 2]))])
                            disc_configs.append(curr_config)
                            disc_ang.append(abs(Delta[bus_nums.index(int(input_configs[i][(3*k)+1]))]-Delta[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                            disc_mag.append(abs(V[bus_nums.index(int(input_configs[i][(3*k)+1]))]-V[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                        elif curr_config[k]==1:
                            conn_names.append([int(input_configs[i][(3 * k) + 1])])
                            conn_names[-1].append(all_from_names[all_from_buses.index(int(input_configs[i][(3 * k) + 1]))])
                            conn_names[-1].append(int(input_configs[i][(3 * k) + 2]))
                            conn_names[-1].append(all_to_names[all_to_buses.index(int(input_configs[i][(3 * k) + 2]))])
                            conn_configs.append(curr_config)
                            conn_ang.append(abs(Delta[bus_nums.index(int(input_configs[i][(3*k)+1]))]-Delta[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                            conn_mag.append(abs(V[bus_nums.index(int(input_configs[i][(3*k)+1]))]-V[bus_nums.index(int(input_configs[i][(3*k)+2]))]))

        tempstr_disc="Outputs_Disc"
        csv_str='%s_%s.csv' % (tempstr_disc,batch+1)
        csv_out = open(csv_str, 'wb')
        mywriter = csv.writer(csv_out, lineterminator='\n')
        for i in range(len(disc_ang)):
            row = []
            row.append(disc_names[i])
            row.append(disc_configs[i])
            row.append(disc_ang[i])
            row.append(disc_mag[i])
            mywriter.writerow(row)
        csv_out.close()

        # tempstr_conn = "Outputs_Conn"
        # csv_str_conn = '%s_%s.csv' % (tempstr_conn, batch+1)
        # csv_out = open(csv_str_conn, 'wb')
        # mywriter = csv.writer(csv_out, lineterminator='\n')
        # for i in range(len(conn_ang)):
        #     row = []
        #     row.append(conn_names[i])
        #     row.append(conn_configs[i])
        #     row.append(conn_ang[i])
        #     row.append(conn_mag[i])
        #     mywriter.writerow(row)
        # csv_out.close()

    disc_ang = []
    conn_ang = []
    disc_mag = []
    conn_mag = []
    disc_names = []
    conn_names = []
    disc_configs = []
    conn_configs = []
    #handle remaining substations
    for i in range(batch_size*(num_batches),batch_size*(num_batches)+remain):
        num_connecs=int(input_configs[i][0])
        if num_connecs>max_size:
            num_connecs=max_size

        #creates truthtable of size corresponding to the number of connections
        table = list(itertools.product([1, 0], repeat=num_connecs))

        #checks each configuration in the truthtable and updates network to match new case
        for j in range(len(table)):

            # reopen psse file to default case
            redirect.psse2py()
            psspy.psseinit(2000000)
            psspy.case(PathSav + '\\' + Sav)
            sid = 1

            curr_config=table[j]
            for k in range(num_connecs):
                if curr_config[k]==0:
                    #psspy.branch_data(int(input_configs[i][(3*k)+1]), int(input_configs[i][(3*k)+2]),input_configs[i][(3*k)+3] , [0])
                    psspy.system_swd_chng(int(input_configs[i][(3*k)+1]), int(input_configs[i][(3*k)+2]),input_configs[i][(3*k)+3] , [0,_i,_i,_i],_f,[_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f],_s)
                    #pdb.set_trace()
            psspy.fnsl()

            bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angled'])
            bus_bases = bus_volt_matrix[1][0]
            V = bus_volt_matrix[1][1]
            Delta = bus_volt_matrix[1][2]  # in degrees

            sol=psspy.solved()
            if sol==0:
                for k in range(num_connecs):
                    if curr_config[k]==0:
                        disc_names.append([int(input_configs[i][(3 * k) + 1])])
                        disc_names[-1].append(all_from_names[all_from_buses.index(int(input_configs[i][(3*k)+1]))])
                        disc_names[-1].append(int(input_configs[i][(3 * k) + 2]))
                        disc_names[-1].append(all_to_names[all_to_buses.index(int(input_configs[i][(3 * k) + 2]))])
                        disc_configs.append(curr_config)
                        disc_ang.append(abs(Delta[bus_nums.index(int(input_configs[i][(3*k)+1]))]-Delta[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                        disc_mag.append(abs(V[bus_nums.index(int(input_configs[i][(3*k)+1]))]-V[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                    elif curr_config[k]==1:
                        conn_names.append([int(input_configs[i][(3 * k) + 1])])
                        conn_names[-1].append(all_from_names[all_from_buses.index(int(input_configs[i][(3 * k) + 1]))])
                        conn_names[-1].append(int(input_configs[i][(3 * k) + 2]))
                        conn_names[-1].append(all_to_names[all_to_buses.index(int(input_configs[i][(3 * k) + 2]))])
                        conn_configs.append(curr_config)
                        conn_ang.append(abs(Delta[bus_nums.index(int(input_configs[i][(3*k)+1]))]-Delta[bus_nums.index(int(input_configs[i][(3*k)+2]))]))
                        conn_mag.append(abs(V[bus_nums.index(int(input_configs[i][(3*k)+1]))]-V[bus_nums.index(int(input_configs[i][(3*k)+2]))]))

    tempstr_disc="Outputs_Disc"
    csv_str='%s_%s.csv' % (tempstr_disc,num_batches+1)
    csv_out = open(csv_str, 'wb')
    mywriter = csv.writer(csv_out, lineterminator='\n')
    for i in range(len(disc_ang)):
        row = []
        row.append(disc_names[i])
        row.append(disc_configs[i])
        row.append(disc_ang[i])
        row.append(disc_mag[i])
        mywriter.writerow(row)
    csv_out.close()

    # tempstr_conn = "Outputs_Conn"
    # csv_str_conn = '%s_%s.csv' % (tempstr_conn, num_batches+1)
    # csv_out = open(csv_str_conn, 'wb')
    # mywriter = csv.writer(csv_out, lineterminator='\n')
    # for i in range(len(conn_ang)):
    #     row = []
    #     row.append(conn_names[i])
    #     row.append(conn_configs[i])
    #     row.append(conn_ang[i])
    #     row.append(conn_mag[i])
    #     mywriter.writerow(row)
    # csv_out.close()
    pdb.set_trace()

if __name__ == "__main__":
    main()