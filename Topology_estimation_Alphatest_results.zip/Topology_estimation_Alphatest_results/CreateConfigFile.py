import os,sys
import csv
installPath = os.path.dirname(os.getcwd())
Library = os.path.dirname(installPath) + '\\Library'
#------------------------------------------------------------------------------#
# NEEDED PATH APPENDICES					               #
#------------------------------------------------------------------------------#
sys.path.append(Library)
pssebindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSBIN"
os.environ['PATH'] = pssebindir + ';' + os.environ['PATH']
sys.path.insert(0,pssebindir)
psspybindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSPY27"
sys.path.insert(0,psspybindir)
#------------------------------------------------------------------------------#
# MODULES       						               #
#------------------------------------------------------------------------------#
import operator, pdb
import psspy

Sav = 'ieee118bus_substations.sav'
#Sav = 'IEEE 14 bus Substations.sav'
#Sav = 'test.sav'

#------------------------------------------------------------------------------#
# USER PATHS								       #
#------------------------------------------------------------------------------#
PathSav = installPath + '\\TopEst'	    # Path for .sav

#------------------------------------------------------------------------------#
# MAIN PROGRAM      						               #
#------------------------------------------------------------------------------#
import redirect
redirect.psse2py()
psspy.psseinit(2000000)
psspy.case(PathSav+'\\'+Sav)
sid = 1
#######################################################################################################################
#----------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------

def main():
    temp=psspy.abrnint(-1,1,1,1,1,['fromnumber','tonumber'])
    all_from_buses=temp[1][0]
    all_to_buses=temp[1][1]
    temp2=psspy.abrnchar(-1,1,1,1,1,['fromname','toname','id'])
    all_from_names=temp2[1][0]
    all_to_names=temp2[1][1]
    all_id=temp2[1][2]

    #obtains list of switches from complete branches list
    switches=[]
    #names=[]
    count=0
    for i in range(len(all_from_buses)):
        from_name=all_from_names[i].partition("_")[0]
        to_name = all_to_names[i].partition("_")[0]
        from_name_short=all_from_names[i][:(all_from_names[i].index("_")-1)]
        to_name_short = all_to_names[i][:(all_to_names[i].index("_") - 1)]
        if from_name==to_name:
            switches.append([all_from_buses[i],all_to_buses[i],all_id[i]])
            #if count == 0:
                #names.append(from_name)
                #count = count + 1
            #elif from_name != names[count - 1]:
                #names.append(from_name)
                #count=count+1
        elif from_name_short==to_name:
            switches.append([all_from_buses[i],all_to_buses[i],all_id[i]])
            #if count == 0:
                #names.append(from_name)
                #count = count + 1
            #elif from_name != names[count - 1]:
                #names.append(from_name)
                #count=count+1
        elif from_name==to_name_short:
            switches.append([all_from_buses[i],all_to_buses[i],all_id[i]])
            #if count == 0:
                #names.append(to_name)
                #count = count + 1
            #elif to_name != names[count - 1]:
                #names.append(to_name)
                #count=count+1


    #determines # of substations and which switches are in substation
    num_subs=0
    num_connecs=[]
    subs=[]
    for x in range(len(switches)):
        if len(subs)==0:
            subs.append(switches[x])
            num_subs=num_subs+1
        else:
            added=0
            for j in range(len(subs)):
                if added==0:
                    if switches[x][0] in subs[j]:
                        for k in range(len(subs)):
                            if switches[x][1] in subs[k]:
                                if j!=k:
                                    subs[j].extend(subs[k])
                                    subs[k]=[0,0]
                        subs[j].extend(switches[x])
                        added=1
                    elif switches[x][1] in subs[j]:
                        if switches[x][0] not in subs[j]:
                            for k in range(len(subs)):
                                if switches[x][0] in subs[k]:
                                    if j != k:
                                        subs[j].extend(subs[k])
                                        subs[k]=[0,0]
                            subs[j].extend(switches[x])
                            added=1
            if added==0:
                subs.append(switches[x])
                num_subs=num_subs+1


    #remove duplicates and adjust substation number
    num_remove=subs.count([0,0])
    for i in range(num_remove):
        subs.remove([0,0])
        num_subs=num_subs-1


    #determines number of connections in each substation
    for i in range(len(subs)):
        num_connecs.append(len(subs[i])/3)

    csv_out = open("ConfigFile.csv", 'wb')
    mywriter = csv.writer(csv_out, lineterminator='\n')
    #mywriter.writerow(num_subs)
    for i in range(num_subs):
        row=[]
        #if i>=len(names):
            #row.append(0)
            #row.append(num_connecs[i])
            #row.extend(subs[i])
        #else:
            #row.append(names[i])
        row.append(num_connecs[i])
        row.extend(subs[i])
        #pdb.set_trace()
        mywriter.writerow(row)
    csv_out.close()

if __name__ == "__main__":
    main()