#from DetConnec import DetConnec_NoInfo
from DetConnec import DetConnec_Est
from DetConnec import DetConnec_Real
import csv
import pdb

def main():

    # reads configuration file
    csv_in = open("ConfigFile_118.csv", 'rb')
    myreader = csv.reader(csv_in, lineterminator='\n')
    configs = []
    for row in myreader:
         configs.append(row)

    sub_nodes=[]
    for i in range(len(configs)):
        for j in range((len(configs[i])-1)/3):
            if j==0:
                sub_nodes.append([int(configs[i][1])])
                sub_nodes[-1].append(int(configs[i][2]))
            else:
                if int(configs[i][3*j+1]) not in sub_nodes[-1]:
                    sub_nodes[-1].append(int(configs[i][3*j+1]))
                if int(configs[i][3*j+2]) not in sub_nodes[-1]:
                    sub_nodes[-1].append(int(configs[i][3*j+2]))
        sub_nodes[-1]=sorted(sub_nodes[-1])

    csv_in = open("Voltages.csv", 'rb')
    myreader = csv.reader(csv_in, lineterminator='\n')
    Voltages = []
    for row in myreader:
        Voltages.append(row)

    csv_in = open("Voltages_1error.csv", 'rb')
    myreader = csv.reader(csv_in, lineterminator='\n')
    Voltages_1 = []
    for row in myreader:
        Voltages_1.append(row)

    csv_in = open("Voltages_3error.csv", 'rb')
    myreader = csv.reader(csv_in, lineterminator='\n')
    Voltages_3 = []
    for row in myreader:
        Voltages_3.append(row)

    csv_in = open("gendata_outputs.csv", 'rb')
    myreader = csv.reader(csv_in, lineterminator='\n')
    outputs = []
    count=0
    for row in myreader:
        for j in range(1,len(row)):
            if count==0:
                outputs.append([float(row[j])])
            else:
                outputs[j-1].append(float(row[j]))
        count=count+1

    outs_emp=[]
    outs_emp1=[]
    outs_emp3=[]
    outs_config=[]
    outs_config1=[]
    outs_config3=[]
    outs_sub=[]
    outs_load=[]
    for i in range(len(outputs)):
        sub_num=int(outputs[i][-1]-1)
        sys_load=float(outputs[i][-2])

        #to get actual topology with known breaker statuses
        out_groups=DetConnec_Real(outputs[i],configs)

        #using known substation configuration
        config_est=DetConnec_Est(Voltages[i],configs)
        config_est1 = DetConnec_Est(Voltages_1[i], configs)
        config_est3 = DetConnec_Est(Voltages_3[i], configs)

        #using differences between values, no configuration knowledge known
        min_node=min(sub_nodes[sub_num])
        max_node=max(sub_nodes[sub_num])
        inp_volts=[]
        inp_volts1=[]
        inp_volts3=[]
        for j in range(min_node,max_node+1):
            inp_volts.append(float(Voltages[i][(2 * j)-1]))
            inp_volts1.append(float(Voltages_1[i][(2 * j) - 1]))
            inp_volts3.append(float(Voltages_3[i][(2 * j) - 1]))

        #emp_est=DetConnec_NoInfo(inp_volts,sub_nodes[sub_num])
        #emp_est1 = DetConnec_NoInfo(inp_volts1, sub_nodes[sub_num])
        #emp_est3 = DetConnec_NoInfo(inp_volts3, sub_nodes[sub_num])

        out_groups_check=sorted(out_groups[sub_num])
        configs_est_check = sorted(config_est[sub_num])
        configs_est_check1 = sorted(config_est1[sub_num])
        configs_est_check3 = sorted(config_est3[sub_num])
        #emp_est_check = sorted(emp_est)
        #emp_est_check1 = sorted(emp_est1)
        #emp_est_check3 = sorted(emp_est3)
        if configs_est_check==out_groups_check:
            outs_config.append(1)
        else:
            outs_config.append(0)
        if configs_est_check1==out_groups_check:
            outs_config1.append(1)
        else:
            outs_config1.append(0)
        if configs_est_check3==out_groups_check:
            outs_config3.append(1)
        else:
            outs_config3.append(0)

        # if emp_est_check==out_groups_check:
        #     outs_emp.append(1)
        # else:
        #     outs_emp.append(0)
        # if emp_est_check1==out_groups_check:
        #     outs_emp1.append(1)
        # else:
        #     outs_emp1.append(0)
        # if emp_est_check3==out_groups_check:
        #     outs_emp3.append(1)
        # else:
        #     outs_emp3.append(0)

        outs_sub.append(sub_num+1)
        outs_load.append(sys_load)

    #find accuracies
    #num_emp=float(len(outs_emp))
    #corr_emp=sum(outs_emp)
    #corr_emp1=sum(outs_emp1)
    #corr_emp3=sum(outs_emp3)
    num_config=float(len(outs_config))
    corr_config=sum(outs_config)
    corr_config1=sum(outs_config1)
    corr_config3=sum(outs_config3)

    #per_emp=corr_emp/num_emp
    #per_emp1=corr_emp1/num_emp
    #per_emp3=corr_emp3/num_emp

    per_config=corr_config/num_config
    per_config1=corr_config1/num_config
    per_config3=corr_config3/num_config

    csv_out = open("EmpericalEstimation.csv", 'wb')
    mywriter = csv.writer(csv_out, lineterminator='\n')
    # row = []
    # row.append('Empirical Technique')
    # row.extend(outs_emp)
    # mywriter.writerow(row)
    # row = []
    # row.append('Empirical Technique 1% error')
    # row.extend(outs_emp1)
    # mywriter.writerow(row)
    # row = []
    # row.append('Empirical Technique 3% error')
    # row.extend(outs_emp3)
    # mywriter.writerow(row)
    row = []
    row.append('Configuration Technique')
    row.extend(outs_config)
    mywriter.writerow(row)
    row = []
    row.append('Configuration Technique 1% error')
    row.extend(outs_config1)
    mywriter.writerow(row)
    row = []
    row.append('Configuration Technique 3% error')
    row.extend(outs_config3)
    mywriter.writerow(row)
    row = []
    row.append('System Load')
    row.extend(outs_load)
    mywriter.writerow(row)
    row = []
    row.append('Substation Number')
    row.extend(outs_sub)
    mywriter.writerow(row)
    csv_out.close()


if __name__ == "__main__":
    main()
