import os,sys
installPath = os.path.dirname(os.getcwd())
Library = os.path.dirname(installPath) + '\\Library'
#------------------------------------------------------------------------------#
# NEEDED PATH APPENDICES					               #
#------------------------------------------------------------------------------#
sys.path.append(Library)
pssebindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSBIN"
os.environ['PATH'] = pssebindir + ';' + os.environ['PATH']
sys.path.insert(0,pssebindir)
psspybindir = "C:\Program Files (x86)\PTI\PSSE34\\PSSPY27"
sys.path.insert(0,psspybindir)
#------------------------------------------------------------------------------#
# MODULES       						               #
#------------------------------------------------------------------------------#
import operator, pdb
import psspy
import csv, itertools
import math,random
import numpy as np


Sav = 'ieee118bus_substations.sav'
Sav_dyr = 'ieee118PSSE_substations.dyr'
OutFileName='Dynamics'
#Sav = 'IEEE 14 bus Substations.sav'
#Sav = 'test.sav'

#------------------------------------------------------------------------------#
# USER PATHS								       #
#------------------------------------------------------------------------------#
PathSav = installPath + '\\TopEst'	    # Path for .sav

#------------------------------------------------------------------------------#
# MAIN PROGRAM      						               #
#------------------------------------------------------------------------------#
import redirect
redirect.psse2py()



_i = psspy.getdefaultint()
_f = psspy.getdefaultreal()
_s = psspy.getdefaultchar()

# reads configuration file
csv_in = open("ConfigFile_118.csv", 'rb')
myreader = csv.reader(csv_in, lineterminator='\n')
input_configs = []
for row in myreader:
    input_configs.append(row)
num_subs = len(input_configs)

error_1ang=.573
error_3ang=1.719
error_1mag=.01
error_3mag=.03

effected_subs=1#math.floor(num_subs*.1)

psspy.psseinit(100000)
psspy.case(PathSav+'\\'+Sav)
sid = 1

psspy.report_output(6,'',[])
psspy.progress_output(6,'',[])
psspy.alert_output(6,'',[])
psspy.prompt_output(6,'',[])

bus_matrix = psspy.abusint(-1, 1,['NUMBER', 'type', 'area', 'zone', 'owner'])  # call the Bus info for the first time
bus_nums = bus_matrix[1][0]

temp=psspy.abrnint(-1,1,1,1,1,['fromnumber','tonumber','status'])
all_from_buses=temp[1][0]
all_to_buses=temp[1][1]
statuses=temp[1][2]
temp2=psspy.abrnchar(-1,1,1,1,1,['fromname','toname','id'])
all_from_names=temp2[1][0]
all_to_names=temp2[1][1]
all_id=temp2[1][2]

load_value_matrix = psspy.aloadcplx(-1, 1, 'mvaact')  # call the Bus info for the first time
load_values = load_value_matrix[1][0]

load_matrix = psspy.aloadint(-1, 1,'NUMBER')  # call the Bus info for the first time
load_nums = load_matrix[1][0]

#obtains list of switches from complete branches list
status=[]
switches=[]
count=0
for i in range(len(all_from_buses)):
    from_name=all_from_names[i].partition("_")[0]
    to_name = all_to_names[i].partition("_")[0]
    from_name_short=all_from_names[i][:(all_from_names[i].index("_")-1)]
    to_name_short = all_to_names[i][:(all_to_names[i].index("_") - 1)]
    if i == 0:
        if from_name == to_name:
            status.append([statuses[i]])
            switches.append([all_from_buses[i], all_to_buses[i]])
        elif from_name_short == to_name:
            status.append([statuses[i]])
            switches.append([all_from_buses[i], all_to_buses[i]])
        elif from_name == to_name_short:
            status.append([statuses[i]])
            switches.append([all_from_buses[i], all_to_buses[i]])
    else:
        if from_name == to_name:
            status[-1].append(statuses[i])
            switches.append([all_from_buses[i], all_to_buses[i]])
        elif from_name_short == to_name:
            status[-1].append(statuses[i])
            switches.append([all_from_buses[i], all_to_buses[i]])
        elif from_name == to_name_short:
            status[-1].append(statuses[i])
            switches.append([all_from_buses[i], all_to_buses[i]])

num_cases=10000
volts=[]
volts_1=[]
volts_3=[]
angs=[]
angs_1=[]
angs_3=[]
outputs=[]
real_load_change=[]
real_load_total=[]
sub_out=[]
for i in range(num_cases):
    psspy.psseinit(100000)
    psspy.case(PathSav + '\\' + Sav)
    sid = 1


    #change load
    real_load_change.append((random.random() - .5) * (sum(np.real(load_values))))
    ind_real_load_changes = real_load_change[i] / len(load_values)
    real_load_total.append(sum(np.real(load_values))+real_load_change[i])

    for j in range(len(load_values)):
        bus_load_num=load_nums[j]
        new_real_load=np.real(load_values[j])+ind_real_load_changes
        new_imag_load = np.imag(load_values[j])# + ind_imag_load_changes
        if new_real_load<0:
            real_load_change[i] = real_load_change[i] + (0 - new_real_load)
            new_real_load=0
        psspy.load_chng_5(bus_load_num, r"""1""", [_i, _i, _i, _i, _i, _i, _i], [new_real_load, new_imag_load, _f, _f, _f, _f, _f, _f])


    #change topology
    outputs.append(status[0][:])
    subs=[]
    frombus=[]
    tobus=[]
    ids=[]
    for j in range(int(effected_subs)):
        rand_sub=random.randint(1,num_subs)
        while rand_sub in subs:
            rand_sub = random.randint(1, num_subs)
        subs.append(rand_sub)
        sub_out.append(rand_sub)
        num_connecs=(len(input_configs[subs[j]-1])-1)/3
        if num_connecs>16:
            num_connecs=16
        table = list(itertools.product([1, 0], repeat=num_connecs))
        config_num=random.randint(1,len(table))-1
        for k in range(len(table[config_num])):
            if table[config_num][k]==0:
                frombus.append(int(input_configs[subs[j]-1][(3*k)+1]))
                tobus.append(int(input_configs[subs[j]-1][(3 * k) + 2]))
                ids.append(input_configs[subs[j]-1][(3 * k) + 3])
                outputs[-1][switches.index([frombus[-1],tobus[-1]])]=0
                psspy.system_swd_chng(frombus[-1],tobus[-1],ids[-1],[0,_i,_i,_i],_f,[_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f,_f],_s)


    psspy.fnsl()

    sol = psspy.solved()
    if sol == 0:
        bus_volt_matrix = psspy.abusreal(-1, 1, ['base', 'pu', 'angled'])
        bus_bases = bus_volt_matrix[1][0]
        V = bus_volt_matrix[1][1]
        Delta = bus_volt_matrix[1][2]  # in degrees
        V_1temp=[]
        V_3temp=[]
        ang_1temp = []
        ang_3temp = []
        for q in range(len(V)):
            V_1temp.append(V[q]+random.gauss(0,error_1mag/3))
            V_3temp.append(V[q] + random.gauss(0,error_3mag/3))
        for q in range(len(Delta)):
            ang_1temp.append(Delta[q]+random.gauss(0,error_1ang/3))
            ang_3temp.append(Delta[q] + random.gauss(0,error_3ang/3))
        volts.append(V)
        volts_1.append(V_1temp)
        volts_3.append(V_3temp)
        angs.append(Delta)
        angs_1.append(ang_1temp)
        angs_3.append(ang_3temp)
    else:
        outputs.pop()
        real_load_total.pop()
        sub_out.pop()

csv_out = open("Voltages.csv", 'wb')
mywriter = csv.writer(csv_out, lineterminator='\n')
for i in range(len(volts)):
    row = []
    for j in range(2*len(volts[i])):
        if j%2==0:
            row.append(volts[i][j/2])
        elif j%2==1:
            row.append(angs[i][(j-1)/2])
    mywriter.writerow(row)
csv_out.close()

csv_out = open("Voltages_1error.csv", 'wb')
mywriter = csv.writer(csv_out, lineterminator='\n')
for i in range(len(volts_1)):
    row = []
    for j in range(2*len(volts_1[i])):
        if j%2==0:
            row.append(volts_1[i][j/2])
        elif j%2==1:
            row.append(angs_1[i][(j-1)/2])
    mywriter.writerow(row)
csv_out.close()

csv_out = open("Voltages_3error.csv", 'wb')
mywriter = csv.writer(csv_out, lineterminator='\n')
for i in range(len(volts_3)):
    row = []
    for j in range(2*len(volts_3[i])):
        if j%2==0:
            row.append(volts_3[i][j/2])
        elif j%2==1:
            row.append(angs_3[i][(j-1)/2])
    mywriter.writerow(row)
csv_out.close()

csv_out = open("gendata_outputs.csv", 'wb')
mywriter = csv.writer(csv_out, lineterminator='\n')
row=[]
for i in range(len(outputs[0])):
    row = []
    row.append(switches[i])
    for j in range(len(outputs)):
        row.append(outputs[j][i])
    mywriter.writerow(row)
row=[]
row.append('system load')
for i in range(len(real_load_total)):
    row.append(real_load_total[i])
mywriter.writerow(row)
row=[]
row.append('sub out')
for i in range(len(sub_out)):
    row.append(sub_out[i])
mywriter.writerow(row)
csv_out.close()