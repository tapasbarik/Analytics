import pdb

def DetConnec_Real(status,configs):

    groupings=[]
    count = 0
    for i in range(len(configs)):
        num_connecs = (len(configs[i]) - 1) / 3
        connec_table = []
        indices = []
        sub_conn = []
        # checks to see which breakers are connected
        for j in range(num_connecs):
            from_node = int(configs[i][(3 * j + 1)])
            to_node = int(configs[i][(3 * j + 2)])
            if j == 0:
                sub_conn.append([from_node])
            if from_node not in sub_conn[-1]:
                sub_conn[-1].append(from_node)
            if to_node not in sub_conn[-1]:
                sub_conn[-1].append(to_node)
            connec_table.append(status[count])
            count=count+1
        sub_conn=sorted(sub_conn)

        # uses breaker connections to check which nodes are connected
        if 0 in connec_table:
            for j in range(len(connec_table)):
                if connec_table[j] == 0:
                    from_node = int(configs[i][(3 * j + 1)])
                    to_node = int(configs[i][(3 * j + 2)])
                    if from_node in sub_conn[0]:
                        sub_conn[0].remove(from_node)
                        sub_conn.append([from_node])
                    if to_node in sub_conn[0]:
                        sub_conn[0].remove(to_node)
                        sub_conn.append([to_node])

            for j in range(len(connec_table)):

                if connec_table[j] == 1:
                    from_node = int(configs[i][(3 * j + 1)])
                    to_node = int(configs[i][(3 * j + 2)])




                    for k in range(len(sub_conn)):
                        if from_node in sub_conn[k]:
                            for l in range(len(sub_conn)):
                                if k != l:
                                    if to_node in sub_conn[l]:
                                        sub_conn[k].extend(sub_conn[l])
                                        sub_conn[l] = [0, 0]
                        elif to_node in sub_conn[k]:
                            for l in range(len(sub_conn)):
                                if k != l:
                                    if from_node in sub_conn[l]:
                                        sub_conn[k].extend(sub_conn[l])
                                        sub_conn[l] = [0, 0]

            num_remove = sub_conn.count([0, 0])
            for j in range(num_remove):
                sub_conn.remove([0, 0])

            num_remove = sub_conn.count([])
            for j in range(num_remove):
                sub_conn.remove([])

        for j in range(len(sub_conn)):
            sub_conn[j]=sorted(sub_conn[j])

        groupings.append(sub_conn)

    return groupings

# def DetConnec_NoInfo(inputs,configs):
#
#     ang_thresh=1
#
#     #test detConnec functions
#     pmu_num=configs
#     sorted_inps = sorted(inputs)
#     inps_ind=sorted(range(len(inputs)),key=lambda k:inputs[k])
#     sorted_pmu=[x for (y,x) in sorted(zip(inputs,pmu_num))]
#     diffs = []
#     for i in range(len(sorted_inps) - 1):
#         diffs.append(sorted_inps[i + 1] - sorted_inps[i])
#     sorted_diffs=sorted(diffs,reverse=True)
#     diffs_ind = sorted(range(len(diffs)), key=lambda k: diffs[k],reverse=True)
#
#     test=0
#     count=0
#     split_nums=[]
#     if(not not sorted_diffs):
#         while(test==0):
#             if(sorted_diffs[count]>ang_thresh):
#                 split_nums.append(diffs_ind[count])
#                 count=count+1
#             else:
#                 test=1
#             if(count>len(sorted_diffs)-1):
#                 test=1
#     split_nums=sorted(split_nums)
#
#     groupings=[]
#     if len(split_nums)==0:
#         groupings.append(pmu_num)
#     else:
#         for i in range(len(split_nums)+1):
#             if i==0:
#                 groupings.append(sorted(sorted_pmu[:split_nums[i]+1]))
#             elif i==len(split_nums):
#                 groupings.append(sorted(sorted_pmu[split_nums[i-1]+1:]))
#             else:
#                 groupings.append(sorted(sorted_pmu[split_nums[i-1]+1:split_nums[i]+1]))
#     return groupings
#
#
#     # GVF=[]
#     # groups=2
#     # curr_GVF=0
#     # #SDAM calculation
#     # avg=sum(sorted_inps)/len(sorted_inps)
#     # temp=[(x-avg)*(x-avg) for x in sorted_inps]
#     # SDAM=sum(temp)
#     # groupings=[]
#     # while(curr_GVF<.95):
#     #     breaks=[]
#     #     for i in range(groups-1):
#     #         breaks.append(diffs_ind[i])
#     #     temp=sorted(breaks)
#     #
#     #     groupings = []
#     #     for i in range(len(breaks)+1):
#     #         if i==0:
#     #             for j in range(0,temp[i]+1):
#     #                 if j==0:
#     #                     groupings.append([sorted_inps[j]])
#     #                 else:
#     #                     groupings[-1].append(sorted_inps[j])
#     #         elif i==len(breaks):
#     #             for j in range(temp[i-1]+1,len(inputs)):
#     #                 if j==temp[i-1]+1:
#     #                     groupings.append([sorted_inps[j]])
#     #                 else:
#     #                     groupings[-1].append(sorted_inps[j])
#     #         else:
#     #             for j in range(temp[i-1]+1,temp[i]+1):
#     #                 if j==temp[i-1]+1:
#     #                     groupings.append([sorted_inps[j]])
#     #                 else:
#     #                     groupings[-1].append(sorted_inps[j])
#     #
#     #     SDCM=0
#     #     SDBC=[]
#     #     for i in range(len(groupings)):
#     #         avg = sum(groupings[i]) / len(groupings[i])
#     #         temp = [(x - avg) * (x - avg) for x in groupings[i]]
#     #         SDBC.append(sum(temp))
#     #         SDCM=SDCM+SDBC[-1]
#     #
#     #     curr_GVF=(SDAM-SDCM)/SDAM
#     #
#     #     GVF.append(curr_GVF)
#     #     groups=groups+1


def DetConnec_Est(inputs,configs,*telemetry):
    ang_thresh=1

    groupings = []
    for i in range(len(configs)):#For each subsation

        #Find Nodes within that substation, ordered sequentially
        num_connecs = (len(configs[i]) - 1) / 3
        indices = []
        sub_conn = []
        # checks to see nodes are in substation, alternatively could be done as an input
        for j in range(num_connecs):
            from_node = int(configs[i][(3 * j + 1)])
            to_node = int(configs[i][(3 * j + 2)])
            if j == 0:
                sub_conn.append([from_node])
            if from_node not in sub_conn[-1]:
                sub_conn[-1].append(from_node)
            if to_node not in sub_conn[-1]:
                sub_conn[-1].append(to_node)
        sub_conn[0] = sorted(sub_conn[0])

        #------------------------------------------------------------------------------------------
        #Step 1
        #------------------------------------------------------------------------------------------
        #Check if Node is energized
        remove_ind=[]
        for j in range(len(sub_conn[0])):
            volt=float(inputs[((2*sub_conn[0][j])-2)])
            if volt<=.8:#find out what value it should be
                remove_ind.append(j)
        for j in range(len(remove_ind)):
            sub_conn[0].remove(sub_conn[0][remove_ind[j]-j])

        # ------------------------------------------------------------------------------------------
        # Step 2
        # ------------------------------------------------------------------------------------------
        #checks for telemetry
        connec_table = []
        if 0 in telemetry:
            for j in range(telemetry):
                if telemetry[j]==0:
                    connec_table.append(0)
                else:
                    connec_table.append(1)
        else:
            for j in range(num_connecs):
                connec_table.append(1)

        # ------------------------------------------------------------------------------------------
        # Step 3
        # ------------------------------------------------------------------------------------------
        #Checks telemetry or infers new breakers
        flag_index=[]
        for j in range(num_connecs):
            from_node = int(configs[i][(3 * j + 1)])
            to_node = int(configs[i][(3 * j + 2)])
            mag_diff = abs(float(inputs[(2 * from_node)-2]) - float(inputs[(2 * to_node)-2]))
            ang_diff = abs(float(inputs[(2 * from_node)-1]) - float(inputs[(2 * to_node)-1]))
            if ang_diff > ang_thresh:
                if connec_table[j]==1:
                    connec_table[j] = 0
                    flag_index.append(j)
                    indices.append(j)
            else:
                if connec_table[j]==0:
                    connec_table[j] = 1
                    flag_index.append(j)


        # ------------------------------------------------------------------------------------------
        # Step 4
        # ------------------------------------------------------------------------------------------
        # uses breaker connections to check which nodes are connected
        if 0 in connec_table:
            for j in range(len(connec_table)):
                if connec_table[j] == 0:
                    from_node = int(configs[i][(3 * j + 1)])
                    to_node = int(configs[i][(3 * j + 2)])
                    if from_node in sub_conn[0]:
                        sub_conn[0].remove(from_node)
                        sub_conn.append([from_node])
                    if to_node in sub_conn[0]:
                        sub_conn[0].remove(to_node)
                        sub_conn.append([to_node])

            for j in range(len(connec_table)):

                if connec_table[j] == 1:
                    from_node = int(configs[i][(3 * j + 1)])
                    to_node = int(configs[i][(3 * j + 2)])

                    for k in range(len(sub_conn)):
                        if from_node in sub_conn[k]:
                            for l in range(len(sub_conn)):
                                if k != l:
                                    if to_node in sub_conn[l]:
                                        sub_conn[k].extend(sub_conn[l])
                                        sub_conn[l] = [0, 0]
                        elif to_node in sub_conn[k]:
                            for l in range(len(sub_conn)):
                                if k != l:
                                    if from_node in sub_conn[l]:
                                        sub_conn[k].extend(sub_conn[l])
                                        sub_conn[l] = [0, 0]

            num_remove = sub_conn.count([0, 0])
            for j in range(num_remove):
                sub_conn.remove([0, 0])

            num_remove = sub_conn.count([])
            for j in range(num_remove):
                sub_conn.remove([])

        for j in range(len(sub_conn)):
            sub_conn[j]=sorted(sub_conn[j])

        groupings.append(sub_conn)

    return groupings

